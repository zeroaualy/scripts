"""
Parser de sinais
Reconhece múltiplos formatos de entrada e MÚLTIPLOS SINAIS simultaneamente
"""
import re
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
import logging

logger = logging.getLogger(__name__)

# Timezone oficial
TZ = ZoneInfo("America/Sao_Paulo")


def parsear_sinal(texto):
    """
    Parser de sinais com múltiplos formatos
    AGORA SUPORTA MÚLTIPLOS SINAIS EM UMA MENSAGEM
    
    Formatos aceitos:
    1. Estruturado:
       ATIVO: EURUSD
       DIREÇÃO: CALL
       TIMEFRAME: 1M
       HORÁRIO: 14:32
       
    2. Com horário: M5 EURUSD CALL 14:30
    3. Imediato: M5 EURUSD CALL ou EURUSD CALL
    4. Lista de sinais (um por linha)
    """
    texto_original = texto
    texto = texto.upper().strip()
    
    # Lista para armazenar múltiplos sinais
    sinais_encontrados = []
    
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # TENTAR FORMATO ESTRUTURADO PRIMEIRO
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    if "ATIVO:" in texto or "DIREÇÃO:" in texto or "DIREÇAO:" in texto:
        sinal = _parsear_estruturado(texto)
        if sinal:
            return [sinal]  # Retorna lista com 1 sinal
    
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # TENTAR MÚLTIPLAS LINHAS (LISTA DE SINAIS)
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    linhas = texto.split('\n')
    
    for linha in linhas:
        linha = linha.strip()
        if not linha or linha.startswith('#') or linha.startswith('//'):
            continue  # Ignora linhas vazias e comentários
        
        # Tentar formato com horário
        padrao_horario = r'(?:M(\d+)\s+)?([A-Z]{6}(?:-OTC)?)\s+(CALL|PUT)\s+(\d{2}):(\d{2})'
        match = re.match(padrao_horario, linha)
        
        if match:
            sinal = _criar_sinal_horario(match)
            if sinal:
                sinais_encontrados.append(sinal)
            continue
        
        # Tentar formato imediato
        padrao_imediato = r'(?:M(\d+)\s+)?([A-Z]{6}(?:-OTC)?)\s+(CALL|PUT)$'
        match = re.match(padrao_imediato, linha)
        
        if match:
            sinal = _criar_sinal_imediato(match)
            if sinal:
                sinais_encontrados.append(sinal)
            continue
    
    # Se encontrou sinais, retorna lista
    if sinais_encontrados:
        logger.info(f"✅ Parseados {len(sinais_encontrados)} sinal(is)")
        return sinais_encontrados
    
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # TENTAR FORMATO ÚNICO (SEM QUEBRA DE LINHA)
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    
    # Formato com horário
    padrao_horario = r'(?:M(\d+)\s+)?([A-Z]{6}(?:-OTC)?)\s+(CALL|PUT)\s+(\d{2}):(\d{2})'
    match = re.match(padrao_horario, texto)
    
    if match:
        sinal = _criar_sinal_horario(match)
        return [sinal] if sinal else None
    
    # Formato imediato
    padrao_imediato = r'(?:M(\d+)\s+)?([A-Z]{6}(?:-OTC)?)\s+(CALL|PUT)$'
    match = re.match(padrao_imediato, texto)
    
    if match:
        sinal = _criar_sinal_imediato(match)
        return [sinal] if sinal else None
    
    logger.warning(f"❌ Formato de sinal não reconhecido: {texto_original}")
    return None


def _parsear_estruturado(texto):
    """Parseia formato estruturado"""
    try:
        linhas = texto.split('\n')
        dados = {}
        
        for linha in linhas:
            if ':' in linha:
                chave, valor = linha.split(':', 1)
                chave = chave.strip().replace('Ç', 'C')
                dados[chave] = valor.strip()
        
        par = dados.get('ATIVO', '').replace('-', '').replace(' ', '')
        direcao = dados.get('DIRECAO', dados.get('DIREÇÃO', ''))
        
        # Timeframe
        timeframe_str = dados.get('TIMEFRAME', '1M')
        minutos = int(timeframe_str.replace('M', '').strip()) if 'M' in timeframe_str else 1
        
        # Horário
        horario_str = dados.get('HORARIO', dados.get('HORÁRIO', ''))
        
        if horario_str and ':' in horario_str:
            hora, minuto = map(int, horario_str.split(':'))
            horario = _criar_horario_sao_paulo(hora, minuto)
            
            return {
                "par": par,
                "direcao": direcao,
                "tempo_expiracao": minutos * 60,
                "horario": horario,
                "imediato": False,
                "formato": "ESTRUTURADO"
            }
        else:
            return {
                "par": par,
                "direcao": direcao,
                "tempo_expiracao": minutos * 60,
                "horario": datetime.now(TZ),
                "imediato": True,
                "formato": "ESTRUTURADO_IMEDIATO"
            }
    except Exception as e:
        logger.error(f"Erro ao parsear sinal estruturado: {e}")
        return None


def _criar_sinal_horario(match):
    """Cria sinal com horário agendado - CORRIGIDO PARA SÃO PAULO"""
    try:
        minutos = int(match.group(1)) if match.group(1) else 1
        par, direcao = match.group(2), match.group(3)
        hora, minuto = int(match.group(4)), int(match.group(5))
        
        horario = _criar_horario_sao_paulo(hora, minuto)
        
        return {
            "par": par,
            "direcao": direcao,
            "tempo_expiracao": minutos * 60,
            "horario": horario,
            "imediato": False,
            "formato": "PADRAO_HORARIO"
        }
    except Exception as e:
        logger.error(f"Erro ao criar sinal com horário: {e}")
        return None


def _criar_sinal_imediato(match):
    """Cria sinal para execução imediata"""
    try:
        minutos = int(match.group(1)) if match.group(1) else 1
        par, direcao = match.group(2), match.group(3)
        
        return {
            "par": par,
            "direcao": direcao,
            "tempo_expiracao": minutos * 60,
            "horario": datetime.now(TZ),
            "imediato": True,
            "formato": "PADRAO_IMEDIATO"
        }
    except Exception as e:
        logger.error(f"Erro ao criar sinal imediato: {e}")
        return None


def _criar_horario_sao_paulo(hora, minuto):
    """
    Cria horário correto no fuso de São Paulo
    CORRIGE O PROBLEMA DE 21h de diferença
    """
    # Obter data/hora ATUAL em São Paulo
    agora_sp = datetime.now(TZ)
    
    # Criar horário desejado HOJE em São Paulo
    horario_sp = agora_sp.replace(
        hour=hora, 
        minute=minuto, 
        second=0, 
        microsecond=0
    )
    
    # Se o horário já passou hoje, agendar para amanhã
    if horario_sp <= agora_sp:
        horario_sp = horario_sp + timedelta(days=1)
        logger.info(f"⏰ Horário {hora:02d}:{minuto:02d} já passou, agendado para amanhã")
    
    logger.info(f"⏰ Sinal agendado para: {horario_sp.strftime('%Y-%m-%d %H:%M:%S %Z')}")
    
    return horario_sp


def validar_sinal(sinal):
    """Valida estrutura do sinal"""
    if not sinal:
        return False
    
    campos_obrigatorios = ["par", "direcao", "tempo_expiracao", "horario"]
    
    for campo in campos_obrigatorios:
        if campo not in sinal:
            logger.error(f"❌ Sinal inválido: campo '{campo}' ausente")
            return False
    
    if sinal["direcao"] not in ["CALL", "PUT"]:
        logger.error(f"❌ Direção inválida: {sinal['direcao']}")
        return False
    
    return True
