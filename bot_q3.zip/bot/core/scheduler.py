"""
Agendador de sinais
Gerencia execução no horário exato
"""
from datetime import datetime
from zoneinfo import ZoneInfo
import logging

logger = logging.getLogger(__name__)

TZ = ZoneInfo("America/Sao_Paulo")


class Scheduler:
    """Agendador preciso de sinais"""
    
    def __init__(self, tolerancia_ms=3000):
        self.tolerancia_segundos = tolerancia_ms / 1000
    
    def verificar_sinais_prontos(self, lista_sinais):
        """
        Verifica quais sinais estão prontos para execução
        Retorna lista de sinais prontos
        """
        agora = datetime.now(TZ)
        sinais_prontos = []
        
        for sinal in lista_sinais:
            horario = sinal.get("horario")
            if not horario:
                continue
            
            # Garantir timezone-aware
            if horario.tzinfo is None:
                horario = horario.replace(tzinfo=TZ)
            
            diferenca = (horario - agora).total_seconds()
            
            # Dentro da tolerância?
            if abs(diferenca) <= self.tolerancia_segundos:
                sinais_prontos.append(sinal)
                logger.info(
                    f"⏰ Sinal pronto: {sinal['par']} {sinal['direcao']} "
                    f"(diferença: {diferenca:.2f}s)"
                )
        
        return sinais_prontos
    
    def tempo_ate_execucao(self, sinal):
        """Retorna tempo em segundos até execução do sinal"""
        agora = datetime.now(TZ)
        horario = sinal.get("horario")
        if not horario:
            return 0
        
        if horario.tzinfo is None:
            horario = horario.replace(tzinfo=TZ)
        
        return (horario - agora).total_seconds()
