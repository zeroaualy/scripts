"""
Configuracoes do Bot Q3 Beta
Fonte unica de verdade para todos os parametros operacionais.

Persistencia: chaves operacionais sao salvas em config_runtime.json
ao lado do .env, e restauradas no proximo startup. Assim configuracoes
como operar_automatico, valor_entrada, martingale etc. sobrevivem a
reinicializacoes do bot.
"""
import os
import json
import logging
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

# Arquivo de persistencia fica na mesma pasta do main.py / .env
_CONFIG_RUNTIME_FILE = Path(__file__).resolve().parent.parent / "config_runtime.json"

# Chaves que sao salvas/restauradas entre restarts.
# Credentials e parametros fixos nao entram aqui.
_PERSISTENT_KEYS = {
    "operar_automatico",
    "valor_entrada",
    "martingale",
    "martingale_multiplier",
    "martingale_max_levels",
    "stop_loss",
    "stop_gain",
    "risco_max_perdas_pausa",
    "max_operacoes_simultaneas",
    "max_slippage_ms",
    "slippage_filter_enabled",
    "min_payout_percent",
    "ia_validar_contexto",
    "automacao_sinais_habilitada",
    "automacao_confianca_minima",
    "automacao_intervalo_analise",
    "automacao_max_sinais_hora",
    "auto_score_threshold",
    "auto_cooldown_seconds",
    "max_auto_trades_per_hour",
    "show_signals_in_chat",
}


def _sanitize(key):
    if not key:
        return None
    return key.strip().strip('"').strip("'").strip() or None


def _load():
    TOKEN = os.getenv("TELEGRAM_TOKEN")
    GRUPO_ID = os.getenv("TELEGRAM_GROUP_ID")
    GEMINI_API_KEY = _sanitize(os.getenv("GEMINI_API_KEY"))
    EMAIL = os.getenv("IQ_EMAIL")
    SENHA = os.getenv("IQ_PASSWORD")

    try:
        GRUPO_ID = int(GRUPO_ID) if GRUPO_ID else None
    except Exception:
        GRUPO_ID = None

    for name, val in [("TELEGRAM_TOKEN", TOKEN), ("TELEGRAM_GROUP_ID", GRUPO_ID),
                      ("IQ_EMAIL", EMAIL), ("IQ_PASSWORD", SENHA)]:
        if not val:
            logger.error(f"{name} nao encontrado no .env")

    return TOKEN, GRUPO_ID, GEMINI_API_KEY, EMAIL, SENHA


def _load_runtime_overrides(config: dict) -> None:
    """Aplica sobrescricoes salvas do ultimo run sobre o CONFIG padrao."""
    if not _CONFIG_RUNTIME_FILE.exists():
        return
    try:
        saved = json.loads(_CONFIG_RUNTIME_FILE.read_text(encoding="utf-8"))
        applied = []
        for key in _PERSISTENT_KEYS:
            if key in saved:
                config[key] = saved[key]
                applied.append(key)
        if applied:
            logger.info(f"CONFIG restaurado do disco: {', '.join(applied)}")
    except Exception as e:
        logger.warning(f"Nao foi possivel carregar config_runtime.json: {e}")


def save_config(config: dict) -> None:
    """
    Persiste as chaves operacionais do CONFIG em disco.
    Chame apos qualquer alteracao de configuracao pelo usuario.
    """
    try:
        data = {k: config[k] for k in _PERSISTENT_KEYS if k in config}
        _CONFIG_RUNTIME_FILE.write_text(
            json.dumps(data, indent=2, ensure_ascii=False),
            encoding="utf-8"
        )
        logger.debug("CONFIG salvo em disco.")
    except Exception as e:
        logger.warning(f"Nao foi possivel salvar config_runtime.json: {e}")


TOKEN, GRUPO_ID, GEMINI_API_KEY, EMAIL, SENHA = _load()

CONFIG = {
    "ativos": ["EURUSD", "GBPUSD", "USDJPY"],
    "timeframe": 60,
    "operar_automatico": False,
    "valor_entrada": 10.0,
    "martingale": False,
    "martingale_multiplier": 2.0,
    "martingale_max_levels": 3,
    "stop_loss": 20.0,
    "stop_gain": 50.0,
    "risco_max_perdas_pausa": 5,
    "max_operacoes_simultaneas": 3,
    "max_slippage_ms": 4000,
    "slippage_filter_enabled": False,
    "bypass_schedule_check": True,
    "min_payout_percent": 70,
    "ia_validar_contexto": False,
    "tolerancia_agendamento_ms": 3000,
    "automacao_sinais_habilitada": True,
    "automacao_confianca_minima": 65,
    "automacao_intervalo_analise": 120,
    "automacao_max_sinais_hora": 10,
    "auto_score_threshold": 65,
    "auto_cooldown_seconds": 120,
    "max_auto_trades_per_hour": 8,
    "show_signals_in_chat": False,
    "debug_trade_validation": False,
}

# Restaura configuracoes do ultimo run (sobrescreve defaults acima)
_load_runtime_overrides(CONFIG)

PERMISSOES = {
    "ia_pode_criar_estrategia": False,
    "ia_pode_prever_mercado": False,
    "ia_pode_decidir_direcao": False,
}
