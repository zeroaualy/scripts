"""
Stats — Bot Q3 Beta
Thin wrapper over DB. No in-memory counters that reset on restart.
"""
from db import database


async def get_today():
    return await database.get_today_stats()


async def get_all_time():
    return await database.get_all_time_stats()


async def get_recent(limit=10):
    return await database.get_recent_trades(limit)


async def get_consecutive_losses():
    return await database.get_consecutive_losses()
