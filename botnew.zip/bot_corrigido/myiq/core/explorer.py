import asyncio
import structlog
import time
from typing import Dict, Any

logger = structlog.get_logger()

# Cache global para init data — TTL 5 minutos
# Evita 7 chamadas WebSocket por sinal (uma por ativo analisado)
_init_data_cache: Dict = {}
_INIT_CACHE_TTL = 300  # segundos


async def get_initialization_data_raw(iq_client, timeout: float = 30.0, retries: int = 3) -> Dict[str, Any]:
    """
    Sends 'get-initialization-data' and waits for the response.
    Cache de 5 minutos — dados de ativos não mudam a cada segundo.
    """
    global _init_data_cache

    # Cache hit
    cached = _init_data_cache.get("data")
    cached_ts = _init_data_cache.get("ts", 0)
    if cached and (time.time() - cached_ts) < _INIT_CACHE_TTL:
        return cached

    req_id = "fetch_init_data"

    for attempt in range(1, retries + 1):
        init_future = asyncio.get_running_loop().create_future()
        
        def on_init(msg):
            if msg.get("name") == "initialization-data":
                if not init_future.done():
                    init_future.set_result(msg)
                    
        iq_client.dispatcher.add_listener("initialization-data", on_init)
        
        try:
            logger.info("fetching_init_data", attempt=attempt, max_retries=retries)
            await iq_client.ws.send({
                "name": "sendMessage",
                "request_id": req_id,
                "msg": {
                    "name": "get-initialization-data",
                    "version": "4.0",
                    "body": {}
                }
            })
            
            # Wait for response with timeout
            raw_res = await asyncio.wait_for(init_future, timeout=timeout)
            data = raw_res.get("msg", {})
            # Update cache
            _init_data_cache["data"] = data
            _init_data_cache["ts"] = time.time()
            logger.debug("init_data_cached")
            return data
            
        except asyncio.TimeoutError:
            logger.warning("init_data_timeout", attempt=attempt)
            if attempt == retries:
                logger.error("init_data_failed_all_attempts")
                raise TimeoutError(f"Falha ao obter dados de inicialização após {retries} tentativas. Verifique sua conexão.")
        except Exception as e:
            logger.error("init_data_error", attempt=attempt, error=str(e))
            if attempt == retries:
                raise
            await asyncio.sleep(1) # Wait a bit before retry on generic error
        finally:
            iq_client.dispatcher.remove_listener("initialization-data", on_init)
    
    return {}

def is_market_open(schedule: list, current_time: int) -> bool:
    """
    Checks if current time is within any of the open intervals.
    IQ Option sends schedule in MILLISECONDS. current_time from get_server_timestamp
    is in SECONDS. Normalize both to seconds for comparison.
    """
    if not schedule:
        return False

    # Detect unit: if values > 1e10 they are in ms, convert to seconds
    for start, end in schedule:
        start_s = int(start / 1000) if start > 1e10 else int(start)
        end_s   = int(end   / 1000) if end   > 1e10 else int(end)
        if start_s <= current_time <= end_s:
            return True
    return False

async def get_all_actives_status(iq_client, instrument_type: str = "turbo") -> Dict[int, Dict[str, Any]]:
    """
    Extracts actives status from initialization data.
    Categories: 'turbo', 'binary', 'digital'
    """
    data = await get_initialization_data_raw(iq_client)
    server_time = iq_client.get_server_timestamp()
    
    category_data = data.get(instrument_type, {})
    actives_dict = category_data.get("actives", {})
    
    results = {}
    for active_id, info in actives_dict.items():
        is_enabled = info.get("enabled", False)
        is_suspended = info.get("is_suspended", False)
        schedule = info.get("schedule", [])
        
        # Check if currently in an open window
        market_open = is_market_open(schedule, server_time)
        
        # Profit Calculation (100 - commission)
        # Note: Structure seems to be option -> profit -> commission
        commission = info.get("option", {}).get("profit", {}).get("commission", 0)
        profit_percent = 100 - commission if commission > 0 else 0

        # Detailed Status
        is_open = is_enabled and not is_suspended and market_open
        results[int(active_id)] = {
            "name": info.get("name"),
            "ticker": info.get("ticker"),
            "enabled": is_enabled,
            "suspended": is_suspended,
            "market_open": market_open,
            "is_open": is_open,
            "profit_percent": profit_percent,
            "image": info.get("image"),
            "schedule": schedule
        }
        
    return results
