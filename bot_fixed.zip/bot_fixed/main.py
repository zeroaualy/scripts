"""
Bot Q3 Beta — Main Entry Point
Unified architecture. Single execution path. Persistent state.
"""
import asyncio
import logging
import time
from datetime import datetime
from zoneinfo import ZoneInfo

from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    filters,
)
from telegram.request import HTTPXRequest

from state.config import TOKEN, GRUPO_ID, GEMINI_API_KEY, EMAIL, SENHA, CONFIG, PERMISSOES
from state import runtime

from core.iq_client import IQClient
from core.signal_parser import parsear_sinal
from core.scheduler import Scheduler
from core.risk_manager import RiskManager
from core.martingale_manager import MartingaleManager
from core.execution_engine import ExecutionEngine
from bot.telegram_bot import TelegramBot
from db import database

TZ = ZoneInfo("America/Sao_Paulo")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# Silencia logs verbosos do httpx (polling do Telegram a cada 10s)
logging.getLogger("httpx").setLevel(logging.WARNING)


# =============================================================
# TELEGRAM NOTIFY FACTORY
# =============================================================

def make_notifier(bot_instance):
    async def notify(msg: str):
        try:
            # Usa create_task para que o Telegram nunca bloqueie o fluxo de trade
            async def _send():
                try:
                    await bot_instance.send_message(
                        chat_id=GRUPO_ID,
                        text=msg,
                        parse_mode="HTML"
                    )
                except Exception as e:
                    logger.error(f"Telegram notify error: {e}")
            asyncio.create_task(_send())
        except Exception as e:
            logger.error(f"Telegram notify task error: {e}")
    return notify


# =============================================================
# SYSTEM INITIALIZATION
# =============================================================

async def inicializar_sistema(app):
    logger.info("Iniciando Bot Q3 Beta...")
    logger.info("=" * 60)

    # Database
    await database.init_db()
    logger.info("SQLite inicializado")

    # IQ Option
    iq_client = IQClient(EMAIL, SENHA, CONFIG)
    conectado = await iq_client.conectar()
    if not conectado:
        logger.warning("IQ Option: sem conexao. Bot funcionara parcialmente.")
    else:
        logger.info("IQ Option conectado")
    runtime.iq_connection = iq_client

    # Martingale Manager
    martingale_manager = MartingaleManager(CONFIG)
    await martingale_manager.load()
    runtime.martingale_manager = martingale_manager
    logger.info("MartingaleManager inicializado")

    # Risk Manager
    risk_manager = RiskManager(CONFIG)
    runtime.risk_manager = risk_manager
    logger.info("RiskManager inicializado")

    # Telegram notify callback
    notify = make_notifier(app.bot)

    # Execution Engine
    execution_engine = ExecutionEngine(
        iq_client=iq_client,
        risk_manager=risk_manager,
        martingale_manager=martingale_manager,
        global_config=CONFIG,
        notify_callback=notify,
    )
    runtime.execution_engine = execution_engine
    logger.info("ExecutionEngine inicializado (Semaphore ativo)")

    # Gemini AI (optional)
    gemini_client = None
    if GEMINI_API_KEY:
        try:
            from core.gemini_client import GeminiClient
            gemini_client = GeminiClient(api_key=GEMINI_API_KEY)
            logger.info("Gemini AI inicializado")
        except Exception as e:
            logger.warning(f"Gemini AI indisponivel: {e}")
    runtime.gemini_client = gemini_client

    # Future Signal Generator / AI Signals (optional)
    try:
        from core.future_signal_generator import FutureSignalGenerator
        future_signal_gen = FutureSignalGenerator(
            iq_client=iq_client,
            gemini_client=gemini_client,
            notify_callback=notify,
            config=CONFIG,
        )
        runtime.future_signal_generator = future_signal_gen
        logger.info("FutureSignalGenerator inicializado (AI Signals pronto)")
    except Exception as e:
        logger.warning(f"FutureSignalGenerator indisponivel: {e}")

    # Auto Signal Generator (optional)
    try:
        from core.auto_signal_generator import AutoSignalGenerator
        auto_signal_gen = AutoSignalGenerator(
            iq_client=iq_client,
            gemini_client=gemini_client,
            runtime=runtime,
            config=CONFIG
        )
        runtime.auto_signal_generator = auto_signal_gen

        async def on_generated_signal(signal):
            signal["signal_source"] = "auto_generator"
            signal["signal_received_at"] = datetime.now(TZ)
            if CONFIG.get("operar_automatico"):
                await execution_engine.execute(
                    signal,
                    signal_received_at=signal["signal_received_at"]
                )

        auto_signal_gen.set_telegram_app(app)
        logger.info("AutoSignalGenerator inicializado")
    except Exception as e:
        logger.warning(f"AutoSignalGenerator indisponivel: {e}")

    # Scheduler
    scheduler = Scheduler(CONFIG.get("tolerancia_agendamento_ms", 3000))

    # Telegram Bot
    signal_parser_obj = type("SP", (), {"parsear_sinal": staticmethod(parsear_sinal)})()
    telegram_bot = TelegramBot(
        config=CONFIG,
        signal_parser=signal_parser_obj,
        permissoes=PERMISSOES,
    )
    telegram_bot.set_iq_client(iq_client)

    # Handlers
    app.add_handler(CommandHandler("start", telegram_bot.start))
    app.add_handler(CommandHandler("resetmartingale", _cmd_reset_martingale))
    app.add_handler(CommandHandler("status", _cmd_status))
    app.add_handler(CallbackQueryHandler(telegram_bot.button_handler))
    app.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND,
        telegram_bot.mensagem
    ))

    # Main loop task
    task = asyncio.create_task(
        loop_principal(app, scheduler, execution_engine)
    )
    app.bot_data["loop_task"] = task
    app.bot_data["scheduler"] = scheduler
    app.bot_data["iq_client"] = iq_client

    logger.info("=" * 60)
    logger.info("Bot Q3 Beta pronto")
    logger.info(f"Conta: PRACTICE obrigatoria")
    logger.info(f"Martingale: {'ATIVO' if CONFIG.get('martingale') else 'desativado'}")
    logger.info(f"Gemini AI: {'disponivel' if gemini_client else 'indisponivel'}")
    logger.info(f"operar_automatico restaurado: {CONFIG.get('operar_automatico')}")


# =============================================================
# EXTRA COMMANDS
# =============================================================

async def _cmd_reset_martingale(update, context):
    if runtime.martingale_manager:
        await runtime.martingale_manager.manual_reset()
        await update.message.reply_text("Martingale resetado. Nivel: 0")
    else:
        await update.message.reply_text("MartingaleManager nao inicializado")


async def _cmd_status(update, context):
    iq = runtime.iq_connection
    conn = "OK" if iq and iq.esta_conectado() else "OFF"
    auto = "ON" if CONFIG.get("operar_automatico") else "OFF"
    mg = runtime.martingale_manager
    mg_txt = ""
    if mg:
        st = mg.get_status()
        mg_txt = (
            f"\nMartingale: {'ON' if st['enabled'] else 'OFF'} "
            f"L{st['level']} ${st['next_value']:.2f}"
        )
    today = await database.get_today_stats()
    saldo_txt = ""
    if iq and iq.esta_conectado():
        try:
            s = await iq.obter_saldo()
            saldo_txt = f"\nSaldo: ${s:.2f}"
        except Exception:
            pass
    await update.message.reply_text(
        f"IQ Option: {conn}\n"
        f"Automatico: {auto}\n"
        f"Hoje: {today['wins']}W {today['losses']}L ${today['pnl']:+.2f}"
        f"{saldo_txt}{mg_txt}",
        parse_mode="HTML"
    )


# =============================================================
# MAIN LOOP
# =============================================================

async def loop_principal(app, scheduler, execution_engine):
    notify = make_notifier(app.bot)
    reconnect_backoff = 5
    _last_status_log = 0  # heartbeat de 30 min

    while True:
        try:
            iq = runtime.iq_connection

            # Auto-reconnect
            if iq and not iq.esta_conectado():
                logger.warning("IQ desconectado, reconectando...")
                try:
                    ok = await asyncio.wait_for(
                        iq.conectar(max_tentativas=2), timeout=60
                    )
                    if ok:
                        reconnect_backoff = 5
                        logger.info("IQ reconectado")
                    else:
                        await asyncio.sleep(reconnect_backoff)
                        reconnect_backoff = min(reconnect_backoff * 2, 120)
                        continue
                except asyncio.TimeoutError:
                    await asyncio.sleep(reconnect_backoff)
                    continue

            # Heartbeat: log simples a cada 30 minutos
            now_ts = time.monotonic()
            if now_ts - _last_status_log >= 1800:
                logger.info("Telegram: Online")
                _last_status_log = now_ts

            # Scheduled signals
            sinais_prontos = scheduler.verificar_sinais_prontos(runtime.sinais_agendados)
            for sinal in sinais_prontos:
                runtime.remover_sinal(sinal)
                if CONFIG.get("operar_automatico"):
                    sinal["signal_source"] = "manual"
                    fired_at = datetime.now(TZ)
                    asyncio.create_task(execution_engine.execute(
                        sinal,
                        signal_received_at=fired_at
                    ))

            # Stop checks (DB-backed — sobrevive restart)
            today = await database.get_today_stats()
            pnl = today.get("pnl", 0.0)

            if pnl <= -abs(CONFIG.get("stop_loss", 20.0)):
                if CONFIG.get("operar_automatico"):
                    CONFIG["operar_automatico"] = False
                    from state.config import save_config
                    save_config(CONFIG)
                    await notify(
                        f"Stop Loss atingido\n"
                        f"Perda: ${abs(pnl):.2f} Limite: ${CONFIG['stop_loss']:.2f}\n"
                        f"Bot pausado automaticamente."
                    )

            if pnl >= CONFIG.get("stop_gain", 50.0):
                if CONFIG.get("operar_automatico"):
                    CONFIG["operar_automatico"] = False
                    from state.config import save_config
                    save_config(CONFIG)
                    await notify(
                        f"Stop Gain atingido\n"
                        f"Lucro: ${pnl:.2f} Meta: ${CONFIG['stop_gain']:.2f}\n"
                        f"Bot pausado automaticamente."
                    )

            await asyncio.sleep(1)

        except asyncio.CancelledError:
            logger.info("Loop cancelado")
            break
        except Exception as e:
            logger.error(f"Loop error: {e}", exc_info=True)
            await asyncio.sleep(5)


# =============================================================
# SHUTDOWN
# =============================================================

async def post_shutdown(application):
    if runtime.future_signal_generator:
        try:
            await runtime.future_signal_generator.stop()
        except Exception:
            pass

    if runtime.auto_signal_generator:
        try:
            await runtime.auto_signal_generator.stop()
        except Exception:
            pass

    if runtime.iq_connection:
        try:
            await runtime.iq_connection.fechar()
        except Exception:
            pass

    task = application.bot_data.get("loop_task")
    if task:
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass

    logger.info("Shutdown completo")


# =============================================================
# ENTRY POINT
# =============================================================

def main():
    request = HTTPXRequest(
        connect_timeout=30.0,
        read_timeout=30.0,
        write_timeout=30.0,
        pool_timeout=30.0,
    )
    app = Application.builder().token(TOKEN).request(request).build()

    async def post_init(application):
        await inicializar_sistema(application)

    app.post_init = post_init
    app.post_shutdown = post_shutdown

    logger.info("=" * 50)
    logger.info("Bot Q3 Beta iniciando polling")
    logger.info("=" * 50)
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
