"""
Gerador Automático de Sinais com IA - Bot Q3 Beta
Analisa mercado e gera sinais automaticamente usando IA Gemini
"""
import asyncio
import logging
import re
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from typing import Optional, Dict, List

logger = logging.getLogger(__name__)
TZ = ZoneInfo("America/Sao_Paulo")


class AISignalGenerator:
    """
    Gerador automático de sinais usando IA.
    
    Fluxo:
    1. Busca candles M1 (60 candles)
    2. Analisa tendência e volatilidade
    3. Envia para IA (Gemini)
    4. Se probabilidade >= 60%, gera sinal
    5. Envia sinal no formato padrão para o grupo
    """
    
    def __init__(self, iq_client, gemini_client, notify_callback, config: dict):
        """
        Args:
            iq_client: Cliente IQ Option
            gemini_client: Cliente Gemini AI
            notify_callback: Função para enviar mensagem no Telegram
            config: Configurações do bot
        """
        self.iq = iq_client
        self.gemini = gemini_client
        self.notify = notify_callback
        self.config = config
        
        # Lista de ativos para análise
        self.ativos = config.get("ai_ativos", ["EURUSD", "GBPUSD", "USDJPY"])
        
        # Probabilidade mínima para gerar sinal
        self.prob_minima = config.get("ai_probabilidade_minima", 60)
        
        # Cache para evitar sinais duplicados
        self._sinais_enviados = {}  # {ativo_direcao_minuto: timestamp}
        
        # Estado de execução
        self.active = False
        self._task = None
        
        # Thread safety: apenas uma predição de IA por vez (Part 8)
        self.ai_lock = asyncio.Lock()
    
    async def start(self):
        """Inicia o gerador automático"""
        if self.active:
            logger.warning("Gerador já está ativo")
            return False
        
        if not self.gemini:
            logger.error("Gemini client não disponível")
            return False
        
        self.active = True
        self._task = asyncio.create_task(self._loop())
        logger.info("✅ Gerador automático de sinais INICIADO")
        return True
    
    async def stop(self):
        """Para o gerador automático"""
        self.active = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        logger.info("⏸️ Gerador automático de sinais PAUSADO")
    
    @staticmethod
    async def sleep_until_next_candle():
        """
        Aguarda até o intervalo entre segundo 50 e 55 do minuto corrente.
        Precisão: ±2 segundos. (Part 5)
        
        Exemplo: se agora é 14:32:20, dorme até 14:32:50.
                 se agora é 14:32:52, dorme até 14:33:50 (próximo minuto).
        """
        now = datetime.now(TZ)
        current_second = now.second + now.microsecond / 1_000_000
        
        # Target: second 52 of current minute (middle of 50-55 window)
        target_second = 52.0
        
        if current_second < target_second:
            sleep_for = target_second - current_second
        else:
            # Already past target in this minute → wait until next minute's target
            sleep_for = (60 - current_second) + target_second
        
        logger.debug(f"⏱️ AI sync: aguardando {sleep_for:.1f}s (target: segundo {target_second})")
        await asyncio.sleep(sleep_for)

    async def _loop(self):
        """Loop principal — sincronizado com o início de cada vela (segundos 50-55)."""
        while self.active:
            try:
                # Sincronizar com a abertura do próximo candle (Part 5)
                await self.sleep_until_next_candle()
                
                if not self.active:
                    break
                
                # Verificar cada ativo na lista
                for ativo in self.ativos:
                    if not self.active:
                        break
                    
                    try:
                        await self.gerar_sinal_se_aprovado(ativo)
                    except Exception as e:
                        logger.error(f"Erro ao gerar sinal para {ativo}: {e}")
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Erro no loop do gerador: {e}")
                await asyncio.sleep(10)
    
    async def gerar_previsao(self, ativo: str) -> Optional[Dict]:
        """
        Gera previsão para um ativo usando IA.
        Thread-safe: apenas uma predição por vez via ai_lock. (Part 8)
        Verifica conexão IQ antes de rodar. (Part 9)
        
        Returns:
            {"direcao": "CALL" | "PUT", "probabilidade": int} ou None
        """
        # Part 9 — Connection validation before AI prediction
        if not self.iq.esta_conectado():
            logger.warning(f"⚠️ IQ desconectado — pulando previsão para {ativo}")
            return None
        
        # Part 8 — Only one AI prediction at a time
        async with self.ai_lock:
            try:
                # 1. Buscar 60 candles M1
                candles = await self._buscar_candles(ativo, timeframe=60, count=60)
                
                if not candles or len(candles) < 30:
                    logger.warning(f"Candles insuficientes para {ativo}")
                    return None
                
                # 2. Calcular métricas
                tendencia = self._calcular_tendencia(candles)
                volatilidade = self._calcular_volatilidade(candles)
                preco_atual = candles[-1]["close"]
                
                # 3. Preparar prompt para IA
                prompt = self._criar_prompt(ativo, candles, tendencia, volatilidade, preco_atual)
                
                # 4. Enviar para IA com timeout
                try:
                    resposta = await asyncio.wait_for(
                        self.gemini.analisar_contexto(prompt),
                        timeout=30.0  # Gemini pode ter até 3 retries × 10s
                    )
                except asyncio.TimeoutError:
                    logger.warning(f"Timeout na IA para {ativo}")
                    return None
                
                # 5. Parsear resposta
                resultado = self._parsear_resposta_ia(resposta)
                
                if resultado:
                    logger.info(
                        f"📊 {ativo}: {resultado['direcao']} "
                        f"({resultado['probabilidade']}%)"
                    )
                
                return resultado
                
            except Exception as e:
                logger.error(f"Erro ao gerar previsão para {ativo}: {e}")
                return None
    
    async def gerar_sinal_se_aprovado(self, ativo: str):
        """
        Gera sinal automaticamente se probabilidade >= 60%
        """
        # Obter previsão da IA
        previsao = await self.gerar_previsao(ativo)
        
        if not previsao:
            return
        
        direcao = previsao["direcao"]
        probabilidade = previsao["probabilidade"]
        
        # Verificar probabilidade mínima
        if probabilidade < self.prob_minima:
            logger.debug(
                f"❌ {ativo} {direcao}: {probabilidade}% < {self.prob_minima}%"
            )
            return
        
        # Verificar duplicação
        agora = datetime.now(TZ)
        minuto_atual = agora.strftime("%H:%M")
        cache_key = f"{ativo}_{direcao}_{minuto_atual}"
        
        if cache_key in self._sinais_enviados:
            logger.debug(f"Sinal duplicado ignorado: {cache_key}")
            return
        
        # Registrar sinal
        self._sinais_enviados[cache_key] = agora.timestamp()
        
        # Limpar cache antigo (> 2 minutos)
        self._limpar_cache_antigo()
        
        # Criar sinal no formato padrão
        horario = (agora + timedelta(seconds=30)).strftime("%H:%M")
        sinal_texto = f"{ativo} {direcao} {horario}"
        
        # Enviar no grupo
        if self.notify:
            mensagem = (
                f"🤖 <b>Sinal IA</b>\n"
                f"📊 {sinal_texto}\n"
                f"🎯 Probabilidade: {probabilidade}%"
            )
            await self.notify(mensagem)
        
        logger.info(f"✅ Sinal IA gerado: {sinal_texto} ({probabilidade}%)")
    
    async def _buscar_candles(self, ativo: str, timeframe: int, count: int) -> List[Dict]:
        """Busca candles históricos. Resolve active_id via IQIntegration antes de chamar get_candles."""
        try:
            # Resolver active_id: get_candles exige int, não símbolo
            active_id = None
            if hasattr(self.iq, "_integration") and self.iq._integration:
                for instrument in ("turbo", "binary", "digital"):
                    active_id = await self.iq._integration._discover_active_id(ativo, instrument)
                    if active_id:
                        break
            
            if not active_id:
                logger.warning(f"active_id não encontrado para {ativo}, pulando candles")
                return []
            
            # get_candles(active_id: int, duration: int, count: int)
            candles = await self.iq.iq.get_candles(int(active_id), timeframe, count)
            
            if not candles:
                return []
            
            # Converter para formato dict
            resultado = []
            for c in candles:
                resultado.append({
                    "open": float(c.open),
                    "high": float(c.max),
                    "low": float(c.min),
                    "close": float(c.close),
                    "time": c.at
                })
            
            return resultado
            
        except Exception as e:
            logger.error(f"Erro ao buscar candles de {ativo}: {e}")
            return []
    
    def _calcular_tendencia(self, candles: List[Dict]) -> str:
        """
        Calcula tendência simples: Alta / Baixa / Lateral
        """
        if len(candles) < 10:
            return "LATERAL"
        
        # Comparar média dos últimos 10 com média dos 10 anteriores
        recentes = candles[-10:]
        anteriores = candles[-20:-10]
        
        media_recente = sum(c["close"] for c in recentes) / len(recentes)
        media_anterior = sum(c["close"] for c in anteriores) / len(anteriores)
        
        diff_percent = ((media_recente - media_anterior) / media_anterior) * 100
        
        if diff_percent > 0.05:
            return "ALTA"
        elif diff_percent < -0.05:
            return "BAIXA"
        else:
            return "LATERAL"
    
    def _calcular_volatilidade(self, candles: List[Dict]) -> str:
        """
        Calcula volatilidade simples: Baixa / Média / Alta
        """
        if len(candles) < 20:
            return "MEDIA"
        
        # Calcular variação média dos últimos 20 candles
        variacoes = []
        for c in candles[-20:]:
            variacao = abs(c["high"] - c["low"]) / c["close"]
            variacoes.append(variacao)
        
        volatilidade_media = sum(variacoes) / len(variacoes)
        
        if volatilidade_media < 0.0005:
            return "BAIXA"
        elif volatilidade_media > 0.002:
            return "ALTA"
        else:
            return "MEDIA"
    
    def _criar_prompt(
        self,
        ativo: str,
        candles: List[Dict],
        tendencia: str,
        volatilidade: str,
        preco_atual: float
    ) -> str:
        """Cria prompt para a IA"""
        
        # Últimos 10 candles
        candles_texto = ""
        for c in candles[-10:]:
            candles_texto += (
                f"open:{c['open']:.5f} high:{c['high']:.5f} "
                f"low:{c['low']:.5f} close:{c['close']:.5f}\n"
            )
        
        agora = datetime.now(TZ)
        
        prompt = f"""Analise este ativo para operação binária de 1 minuto:

Ativo: {ativo}
Timeframe: M1
Hora atual: {agora.strftime('%H:%M')}
Preço atual: {preco_atual:.5f}
Tendência: {tendencia}
Volatilidade: {volatilidade}

Últimos candles:
{candles_texto}

Responda EXATAMENTE neste formato (sem texto extra):
DIRECAO: CALL
PROBABILIDADE: 65

Ou:
DIRECAO: PUT
PROBABILIDADE: 70
"""
        return prompt
    
    def _parsear_resposta_ia(self, resposta: str) -> Optional[Dict]:
        """
        Parseia resposta da IA com regex estrito. (Part 7)
        Se inválida, descarta silenciosamente — nunca crasha.
        
        Formato esperado:
        DIRECTION: CALL
        PROBABILITY: 65
        ou (PT):
        DIRECAO: CALL
        PROBABILIDADE: 65
        """
        if not resposta or not isinstance(resposta, str):
            return None
        try:
            texto = resposta.upper().strip()

            # Match DIRECTION (EN) or DIRECAO/DIREÇÃO (PT)
            dir_match = re.search(
                r'(?:DIRECTION|DIRE[CÇ][AÃ]O)\s*:\s*(CALL|PUT)',
                texto
            )
            # Match PROBABILITY (EN) or PROBABILIDADE (PT)
            prob_match = re.search(
                r'(?:PROBABILITY|PROBABILIDADE)\s*:\s*(\d{1,3})',
                texto
            )

            if not dir_match or not prob_match:
                logger.warning(f"Resposta IA inválida (regex): {resposta[:120]}")
                return None

            direcao = dir_match.group(1).strip()
            probabilidade = int(prob_match.group(1).strip())

            if direcao not in ("CALL", "PUT"):
                logger.warning(f"Direção inválida na resposta IA: {direcao}")
                return None

            if not (0 <= probabilidade <= 100):
                logger.warning(f"Probabilidade fora de intervalo: {probabilidade}")
                return None

            return {"direcao": direcao, "probabilidade": probabilidade}

        except Exception as e:
            logger.error(f"Erro ao parsear resposta IA: {e}")
            return None
    
    def _limpar_cache_antigo(self):
        """Remove sinais do cache com mais de 2 minutos"""
        agora = datetime.now(TZ).timestamp()
        limite = agora - 120  # 2 minutos
        
        keys_remover = [
            k for k, ts in self._sinais_enviados.items()
            if ts < limite
        ]
        
        for key in keys_remover:
            del self._sinais_enviados[key]
