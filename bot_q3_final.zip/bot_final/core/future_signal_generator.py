"""
Gerador de Agenda Diária de Sinais IA — Bot Q3 Beta
Gera uma lista completa de sinais para o dia usando Gemini AI + dados de mercado MyIQ.

Funcionalidades de segurança preservadas:
- asyncio.Lock(): apenas uma requisição IA por vez
- last_ai_call_timestamp: intervalo mínimo entre chamadas (30s)
- Retry: 3 tentativas, 10s entre tentativas, timeout de 45s por chamada
- Verificação de conexão antes de executar
- Nunca derruba o bot

Arquitetura:
- Gera UMA lista completa por dia (não sinais individuais por minuto)
- Envia UMA mensagem Telegram com a agenda completa (formato: ATIVO DIRECAO HH:MM)
- Injeta sinais diretamente no runtime com tempo_expiracao=300 e immediate=False
- AutoTrade executa os sinais automaticamente no horário correto
- OTC permitido apenas após 18:00 (horário São Paulo)
"""
import asyncio
import json
import logging
import re
import time
from datetime import datetime, timedelta
from typing import List, Optional, Dict
from zoneinfo import ZoneInfo

logger = logging.getLogger(__name__)
TZ = ZoneInfo("America/Sao_Paulo")

# ─────────────────────────────────────────────────────────
# POOL DE ATIVOS E HORÁRIOS DE CADA SESSÃO
# ─────────────────────────────────────────────────────────

_ATIVOS_DIA = [
    "EURUSD", "GBPUSD", "USDJPY", "AUDUSD",
    "EURJPY", "GBPJPY", "EURGBP", "AUDJPY", "USDCAD",
]
_ATIVOS_OTC = [
    "EURUSD-OTC", "GBPUSD-OTC", "USDJPY-OTC", "AUDUSD-OTC",
    "EURJPY-OTC", "GBPJPY-OTC", "EURGBP-OTC", "AUDJPY-OTC", "USDCAD-OTC",
]

# ─────────────────────────────────────────────────────────
# HORÁRIOS — Espaçamento: mínimo 20 min, máximo 30 min, alvo 25 min
# Total: 20 sinais regulares + 12 OTC = 32 sinais (dentro de 20-40)
# OTC APENAS após 18:00 (horário São Paulo)
# ─────────────────────────────────────────────────────────
_HORARIOS_DIA = [
    "09:20", "09:45", "10:10", "10:35", "11:00",
    "11:25", "11:50", "12:15", "12:40", "13:05",
    "13:30", "13:55", "14:20", "14:45", "15:10",
    "15:35", "16:00", "16:25", "16:50", "17:15",
]  # 20 sinais — mercado aberto (regulares)

_HORARIOS_OTC = [
    "18:00", "18:25", "18:50", "19:15", "19:40",
    "20:05", "20:30", "20:55", "21:20", "21:45",
    "22:10", "22:35",
]  # 12 sinais — OTC (apenas após 18:00)

# Horário do ciclo diário (São Paulo)
_HORA_GERACAO = 9
_MINUTO_GERACAO = 0

# Intervalo mínimo entre chamadas Gemini (segundos)
MIN_CALL_INTERVAL = 30.0

_PROB_MINIMA_PADRAO = 0.60

# Expiração padrão para todos os sinais da agenda diária (5 minutos)
_TEMPO_EXPIRACAO_AGENDA = 300


def _gerar_slots(horarios: List[str], ativos_pool: List[str]) -> List[Dict]:
    """Distribui ativos em rotação pelo pool para cada horário."""
    n = len(ativos_pool)
    return [{"time": t, "asset": ativos_pool[i % n]} for i, t in enumerate(horarios)]


# Pré-computação dos slots do dia (imutáveis)
_SLOTS_DIA = _gerar_slots(_HORARIOS_DIA, _ATIVOS_DIA)
_SLOTS_OTC = _gerar_slots(_HORARIOS_OTC, _ATIVOS_OTC)
_TODOS_SLOTS = _SLOTS_DIA + _SLOTS_OTC


class FutureSignalGenerator:
    """
    Gerador de agenda diária de sinais via IA.

    Ciclo: gera ao iniciar → aguarda 09:00 SP → repete.
    Envia uma única mensagem Telegram com os sinais no formato: ATIVO DIRECAO HH:MM
    (sem cabeçalhos, sem separadores, sem prefixos — uma linha por sinal)
    Injeta sinais no runtime com tempo_expiracao=300 e immediate=False.
    OTC apenas após 18:00 (horário São Paulo).
    """

    def __init__(self, iq_client, gemini_client, notify_callback, config: dict, runtime=None):
        self.iq = iq_client
        self.gemini = gemini_client
        self.notify = notify_callback
        self.config = config
        self.runtime = runtime  # opcional: para injeção direta com tempo_expiracao=300

        self.prob_minima = float(config.get("ai_probabilidade_minima", _PROB_MINIMA_PADRAO))
        self._last_ai_call_timestamp: float = 0.0
        self.ai_lock = asyncio.Lock()
        self.active = False
        self._task: Optional[asyncio.Task] = None

    # ──────────────────────────────────────────────
    # CICLO DE VIDA
    # ──────────────────────────────────────────────

    async def start(self) -> bool:
        if self.active:
            logger.warning("⚠️ FutureSignalGenerator já está ativo")
            return False
        if not self.gemini:
            logger.error("❌ GeminiClient não disponível para o gerador de agenda")
            return False
        self.active = True
        self._task = asyncio.create_task(self._loop())
        logger.info("✅ 🔮 FutureSignalGenerator INICIADO — modo agenda diária (20-40 sinais, OTC após 18:00)")
        return True

    async def stop(self):
        self.active = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        logger.info("⏸️ 🔮 FutureSignalGenerator PAUSADO")

    # ──────────────────────────────────────────────
    # LOOP PRINCIPAL
    # ──────────────────────────────────────────────

    async def _loop(self):
        """Gera agenda imediatamente ao iniciar, depois a cada dia às 09:00 SP."""
        while self.active:
            try:
                if not self.iq.esta_conectado():
                    logger.warning("⚠️ IQ Option desconectada — aguardando 30s...")
                    await asyncio.sleep(30)
                    continue

                elapsed = time.monotonic() - self._last_ai_call_timestamp
                if elapsed < MIN_CALL_INTERVAL:
                    await asyncio.sleep(MIN_CALL_INTERVAL - elapsed)
                    continue

                logger.info("📊 🔮 Iniciando geração da agenda diária de sinais IA...")
                await self._gerar_e_enviar_agenda()
                await self._aguardar_proximo_ciclo()

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"❌ Erro no loop da agenda diária: {e}")
                await asyncio.sleep(60)

    # ──────────────────────────────────────────────
    # PIPELINE DE GERAÇÃO
    # ──────────────────────────────────────────────

    async def _gerar_e_enviar_agenda(self):
        """Pipeline: mercado → prompt → Gemini → parse → filtrar → formatar → enviar."""
        async with self.ai_lock:
            elapsed = time.monotonic() - self._last_ai_call_timestamp
            if elapsed < MIN_CALL_INTERVAL:
                return

            try:
                contexto = await self._coletar_contexto_mercado()
                prompt = self._construir_prompt_diario(contexto)

                logger.info("🧠 Consultando Gemini para agenda diária...")
                resposta_raw = await self._chamar_gemini_com_retry(prompt)
                self._last_ai_call_timestamp = time.monotonic()

                if resposta_raw is None:
                    logger.warning("⚠️ Gemini não retornou resposta — agenda não gerada")
                    return

                sinais = self._parsear_resposta_diaria(resposta_raw)
                if not sinais:
                    logger.warning("⚠️ Nenhum sinal válido na resposta da IA")
                    return

                aprovados = [
                    s for s in sinais
                    if float(s.get("probability", 0)) >= self.prob_minima
                ]
                if not aprovados:
                    logger.warning(
                        f"⚠️ Nenhum sinal com prob ≥ {self.prob_minima:.0%} — "
                        "agenda não enviada"
                    )
                    return

                logger.info(
                    f"✅ {len(aprovados)} sinais aprovados "
                    f"(prob ≥ {self.prob_minima:.0%}) de {len(sinais)} analisados"
                )

                mensagem = self._formatar_agenda(aprovados)
                if not mensagem:
                    logger.warning("⚠️ Agenda formatada vazia — nenhuma mensagem enviada")
                    return

                if self.notify:
                    await self.notify(mensagem)
                    logger.info("📤 ✅ Agenda diária de sinais IA enviada ao Telegram")

                # Injetar sinais diretamente no runtime com tempo_expiracao=300 e immediate=False
                if self.runtime:
                    await self._injetar_sinais_no_runtime(aprovados)

            except Exception as e:
                self._last_ai_call_timestamp = time.monotonic()
                logger.error(f"❌ Erro ao gerar agenda diária: {e}")

    # ──────────────────────────────────────────────
    # COLETA DE CONTEXTO DE MERCADO
    # ──────────────────────────────────────────────

    async def _coletar_contexto_mercado(self) -> Dict:
        """Coleta candles M1 de EURUSD, GBPUSD e USDJPY como contexto de mercado."""
        ativos = ["EURUSD", "GBPUSD", "USDJPY"]
        dados = {}
        for ativo in ativos:
            try:
                candles = await self._buscar_candles(ativo)
                if candles and len(candles) >= 5:
                    dados[ativo] = candles
            except Exception as e:
                logger.debug(f"⚠️ Candles indisponíveis para {ativo}: {e}")
        return dados

    async def _buscar_candles(self, ativo: str) -> List[Dict]:
        """Busca candles M1 resolvendo active_id via integration layer."""
        try:
            active_id = None
            if hasattr(self.iq, "_integration") and self.iq._integration:
                symbol_clean = ativo.replace("-OTC", "")
                for instrument in ("turbo", "binary", "digital"):
                    active_id = await self.iq._integration._discover_active_id(
                        symbol_clean, instrument
                    )
                    if active_id:
                        break

            if not active_id:
                return []

            raw = await self.iq.iq.get_candles(int(active_id), 60, 20)
            return [
                {
                    "open": float(c.open),
                    "high": float(c.max),
                    "low": float(c.min),
                    "close": float(c.close),
                    "time": c.at,
                }
                for c in raw
            ]
        except Exception as e:
            logger.debug(f"⚠️ Erro ao buscar candles de {ativo}: {e}")
            return []

    # ──────────────────────────────────────────────
    # CONSTRUÇÃO DO PROMPT
    # ──────────────────────────────────────────────

    def _construir_prompt_diario(self, contexto: Dict) -> str:
        """Constrói o prompt completo para a agenda diária."""
        agora = datetime.now(TZ)

        # Resumo dos dados de mercado
        linhas_mkt = []
        for ativo, candles in contexto.items():
            if candles:
                ult = candles[-1]
                ant = candles[-5] if len(candles) >= 5 else candles[0]
                var = ((ult["close"] - ant["close"]) / ant["close"]) * 100
                tendencia = "ALTA" if var > 0 else "BAIXA"
                linhas_mkt.append(
                    f"  {ativo}: close={ult['close']:.5f}  variação={var:+.3f}%  tendência={tendencia}"
                )
        resumo_mkt = "\n".join(linhas_mkt) if linhas_mkt else "  (dados não disponíveis)"

        # Lista de slots numerados para preenchimento pelo Gemini
        linhas_slots = "\n".join(
            f'  {{"idx": {i}, "time": "{s["time"]}", "asset": "{s["asset"]}"}}'
            for i, s in enumerate(_TODOS_SLOTS)
        )

        return f"""Você é um analista de opções binárias. Analise os dados e gere uma agenda de sinais para o dia.

HORÁRIO ATUAL (São Paulo): {agora.strftime('%d/%m/%Y %H:%M:%S')}

DADOS DE MERCADO (M1 – 20 últimas velas):
{resumo_mkt}

INSTRUÇÕES:
- Analise cada slot e decida a direção (CALL ou PUT)
- probability deve ser decimal 0.00 a 1.00
- Inclua APENAS slots com probability >= {self.prob_minima:.2f}
- Omita slots com probability abaixo de {self.prob_minima:.2f}
- Ativos com -OTC operam em mercado OTC (noite)
- Retorne SOMENTE JSON válido, sem texto extra, sem markdown

SLOTS DISPONÍVEIS:
[
{linhas_slots}
]

FORMATO DE RESPOSTA (array com apenas os slots aprovados):
[
  {{"idx": 0, "direction": "PUT", "probability": 0.72}},
  {{"idx": 3, "direction": "CALL", "probability": 0.68}}
]

Se nenhum slot tiver probability >= {self.prob_minima:.2f}, retorne: []
"""

    # ──────────────────────────────────────────────
    # CHAMADA GEMINI COM RETRY
    # ──────────────────────────────────────────────

    async def _chamar_gemini_com_retry(self, prompt: str) -> Optional[str]:
        """3 tentativas · 45s timeout cada · 10s entre tentativas."""
        for tentativa in range(1, 4):
            try:
                return await asyncio.wait_for(
                    self.gemini.analisar_contexto(prompt, temperature=0.3),
                    timeout=45.0,
                )
            except asyncio.TimeoutError:
                logger.warning(f"⏱️ Gemini timeout (tentativa {tentativa}/3)")
                if tentativa < 3:
                    await asyncio.sleep(10.0)
            except RuntimeError as e:
                logger.warning(f"⚠️ Gemini rate limit: {e}")
                return None
            except Exception as e:
                logger.warning(f"⚠️ Gemini erro tentativa {tentativa}/3: {e}")
                if tentativa < 3:
                    await asyncio.sleep(10.0)

        logger.error("❌ Gemini: todas as tentativas falharam — agenda cancelada")
        return None

    # ──────────────────────────────────────────────
    # PARSER DA RESPOSTA
    # ──────────────────────────────────────────────

    def _parsear_resposta_diaria(self, raw: str) -> List[Dict]:
        """
        Parseia array JSON da resposta Gemini.
        Resolve cada item ao slot correspondente via idx.
        Retorna lista de sinais válidos ou lista vazia em qualquer erro.
        """
        if not raw or not isinstance(raw, str):
            return []
        try:
            text = raw.strip()
            text = re.sub(r"^```(?:json)?\s*", "", text)
            text = re.sub(r"\s*```$", "", text)
            text = text.strip()

            data = json.loads(text)
            if not isinstance(data, list):
                logger.warning(f"⚠️ Resposta Gemini não é array: {text[:100]}")
                return []

            resultado = []
            for item in data:
                if not isinstance(item, dict):
                    continue

                direction = str(item.get("direction", "")).upper().strip()
                if direction not in ("CALL", "PUT"):
                    continue

                try:
                    prob = float(item.get("probability", 0))
                except (TypeError, ValueError):
                    continue
                if not (0.0 <= prob <= 1.0):
                    continue

                idx = item.get("idx")
                slot = None
                if idx is not None:
                    try:
                        slot = _TODOS_SLOTS[int(idx)]
                    except (IndexError, TypeError, ValueError):
                        pass

                if slot is None:
                    continue

                resultado.append({
                    "time": slot["time"],
                    "asset": slot["asset"],
                    "direction": direction,
                    "probability": prob,
                })

            return resultado

        except json.JSONDecodeError as e:
            logger.warning(f"⚠️ JSON inválido na resposta Gemini: {e} | raw: {raw[:200]}")
            return []
        except Exception as e:
            logger.error(f"❌ Erro ao parsear resposta diária: {e}")
            return []

    # ──────────────────────────────────────────────
    # FORMATAÇÃO DA AGENDA
    # ──────────────────────────────────────────────

    def _formatar_agenda(self, sinais: List[Dict]) -> str:
        """
        Formata os sinais aprovados em linhas puras.

        Formato de cada linha (EXATO):
            ATIVO DIRECAO HH:MM

        Exemplos:
            EURUSD CALL 09:20
            GBPUSD PUT 09:45
            USDCAD-OTC CALL 20:05

        Regex de validação: ^[A-Z]{6}(-OTC)? (CALL|PUT) [0-2][0-9]:[0-5][0-9]$

        Regras:
        - Sem cabeçalhos
        - Sem separadores
        - Sem emojis
        - Sem prefixo M5
        - Sem texto extra antes ou depois
        - Uma linha por sinal
        """
        if not sinais:
            return ""

        # Ordenar por horário
        sinais_ordenados = sorted(sinais, key=lambda s: s["time"])

        linhas = []
        for s in sinais_ordenados:
            asset = s["asset"].strip().upper()
            direction = s["direction"].strip().upper()
            time_str = s["time"].strip()
            # Validar regex antes de incluir
            import re as _re
            if _re.match(r'^[A-Z]{6}(-OTC)? (CALL|PUT) [0-2][0-9]:[0-5][0-9]$',
                         f"{asset} {direction} {time_str}"):
                linhas.append(f"{asset} {direction} {time_str}")
            else:
                logger.warning(f"⚠️ Sinal ignorado na formatação (formato inválido): {asset} {direction} {time_str}")

        return "\n".join(linhas)

    async def _injetar_sinais_no_runtime(self, sinais: List[Dict]):
        """
        Injeta sinais diretamente no runtime com:
        - tempo_expiracao = 300 (5 minutos)
        - immediate = False
        - horario calculado a partir de HH:MM (horário São Paulo)

        Preserva compatibilidade total com o AutoTrade existente.
        """
        from datetime import datetime, timedelta
        agora = datetime.now(TZ)
        injetados = 0
        ignorados = 0

        for s in sinais:
            try:
                hora, minuto = map(int, s["time"].split(":"))
                horario_sp = agora.replace(hour=hora, minute=minuto, second=0, microsecond=0)

                # Se o horário já passou hoje, agendar para amanhã
                if horario_sp <= agora:
                    horario_sp += timedelta(days=1)

                sinal_dict = {
                    "par": s["asset"],
                    "direcao": s["direction"],
                    "tempo_expiracao": _TEMPO_EXPIRACAO_AGENDA,  # 300s
                    "horario": horario_sp,
                    "imediato": False,
                    "formato": "AGENDA_IA",
                    "origem": "FUTURE_SIGNAL_GENERATOR",
                }

                if hasattr(self.runtime, "adicionar_sinal"):
                    self.runtime.adicionar_sinal(sinal_dict)
                    injetados += 1
                else:
                    logger.warning("⚠️ runtime.adicionar_sinal não disponível")
                    break

            except Exception as e:
                logger.warning(f"⚠️ Erro ao injetar sinal {s}: {e}")
                ignorados += 1

        logger.info(f"📅 Runtime: {injetados} sinais injetados (tempo_expiracao=300), {ignorados} ignorados")

    # ──────────────────────────────────────────────
    # TEMPORIZAÇÃO DO CICLO DIÁRIO
    # ──────────────────────────────────────────────

    async def _aguardar_proximo_ciclo(self):
        """Aguarda até 09:00 São Paulo do próximo dia, respondendo rapidamente ao stop()."""
        if not self.active:
            return

        agora = datetime.now(TZ)
        proximo = agora.replace(
            hour=_HORA_GERACAO, minute=_MINUTO_GERACAO, second=0, microsecond=0
        )
        if proximo <= agora:
            proximo += timedelta(days=1)

        total_s = (proximo - agora).total_seconds()
        logger.info(
            f"⏰ 🔮 Próxima agenda em "
            f"{int(total_s // 3600)}h {int((total_s % 3600) // 60)}min "
            f"({proximo.strftime('%d/%m %H:%M')} SP)"
        )

        # Dorme em fatias de 60s para responder ao stop() sem demora excessiva
        while self.active:
            restante = (proximo - datetime.now(TZ)).total_seconds()
            if restante <= 0:
                break
            await asyncio.sleep(min(60.0, restante))
