"""
IQ Integration Layer - Bot Q3 Beta
Camada de integração usando APENAS métodos públicos do myiq
"""
import asyncio
import logging
from typing import Tuple, Optional, Dict
from datetime import datetime

logger = logging.getLogger(__name__)


class IQIntegration:
    """
    Camada de integração IQ Option usando APENAS API pública do myiq.
    
    Princípios:
    - Zero acesso a propriedades internas
    - Validação LIVE sempre
    - Seleção dinâmica de instrumento (turbo vs digital)
    - Erros precisos da API
    """
    
    def __init__(self, iq_client, config: dict):
        """
        Args:
            iq_client: Instância do cliente myiq
            config: Configurações do bot
        """
        self.iq = iq_client
        self.config = config
        self.practice_balance_id = None
        self.real_balance_id = None  # Cache do ID da conta REAL
        self._last_trade_time: Optional[datetime] = None
        self._pending_trade = False
        self._actives_map = {}  # Cache local (não interno do myiq)
        self._last_trade_result = {}  # {order_id: raw_result_dict}
        self._active_id_cache = {}   # {(symbol, instrument): (active_id, ts)} TTL 5min
    
    async def ensure_connection(self) -> bool:
        """Garante que websocket está conectado"""
        try:
            if not self.iq or not self.iq.check_connect():
                logger.error("❌ Websocket desconectado")
                return False
            return True
        except Exception as e:
            logger.error(f"❌ Erro ao verificar conexão: {e}")
            return False
    
    async def ensure_practice_account(self) -> bool:
        """
        Garante que está operando em conta PRACTICE.
        Usa apenas métodos públicos.
        """
        try:
            if not await self.ensure_connection():
                return False

            balances = await self.iq.get_balances()
            if not balances:
                logger.error("❌ Não foi possível obter balanços")
                return False

            practice = next((b for b in balances if b.type == 4), None)
            if not practice:
                logger.error("❌ Conta PRACTICE não encontrada")
                return False

            if self.iq.active_balance_id == practice.id:
                self.practice_balance_id = practice.id
                return True

            logger.info("🔄 Mudando para conta PRACTICE...")
            await self.iq.change_balance(practice.id)
            self.practice_balance_id = practice.id

            if self.iq.active_balance_id == practice.id:
                logger.info("✅ Operando na conta PRACTICE")
                return True
            else:
                logger.error("❌ Falha ao mudar para PRACTICE")
                return False

        except Exception as e:
            logger.error(f"❌ Erro ao garantir PRACTICE: {e}")
            return False

    async def alternar_conta(self, modo: str) -> tuple:
        """
        Alterna entre conta PRACTICE e REAL.

        Args:
            modo: "PRACTICE" ou "REAL"

        Returns:
            (sucesso: bool, saldo: float, tipo: str, mensagem: str)
        """
        # type == 4 → PRACTICE | type == 1 → REAL
        TYPE_MAP = {"PRACTICE": 4, "REAL": 1}
        target_type = TYPE_MAP.get(modo.upper())
        if not target_type:
            return False, 0.0, "", "Modo inválido. Use PRACTICE ou REAL."

        try:
            if not await self.ensure_connection():
                return False, 0.0, "", "WebSocket desconectado"

            balances = await self.iq.get_balances()
            if not balances:
                return False, 0.0, "", "Não foi possível obter balanços"

            target = next((b for b in balances if b.type == target_type), None)
            if not target:
                return False, 0.0, "", f"Conta {modo} não encontrada na sua conta IQ Option"

            # Já está na conta correta?
            if self.iq.active_balance_id == target.id:
                tipo_str = "PRACTICE" if target_type == 4 else "REAL"
                return True, float(target.amount), tipo_str, f"Já está em {tipo_str}"

            await self.iq.change_balance(target.id)

            if self.iq.active_balance_id == target.id:
                tipo_str = "PRACTICE" if target_type == 4 else "REAL"
                # Salvar IDs para referência futura
                if target_type == 4:
                    self.practice_balance_id = target.id
                else:
                    self.real_balance_id = target.id
                logger.info(f"✅ Conta alterada para {tipo_str} | Saldo: ${target.amount:.2f}")
                return True, float(target.amount), tipo_str, "OK"
            else:
                return False, 0.0, "", f"Falha ao mudar para {modo}"

        except Exception as e:
            logger.error(f"❌ Erro ao alternar conta: {e}")
            return False, 0.0, "", str(e)
    
    async def _discover_active_id(self, asset_symbol: str, instrument: str) -> Optional[int]:
        """
        Descobre active_id com:
        - Cache em memória (5 min)
        - Mapeamento persistente no SQLite (sobrevive restart)
        - Auto-correção: tenta variações do símbolo automaticamente
        - Log detalhado quando falha para facilitar diagnóstico
        """
        import time
        from db import database

        symbol_upper = asset_symbol.upper().replace("/", "").replace("-OTC", "").replace(" ", "")
        is_otc = "-OTC" in asset_symbol.upper()
        cache_key = (symbol_upper, instrument)

        # 1. Cache em memória
        cached = self._active_id_cache.get(cache_key)
        if cached:
            active_id, ts = cached
            if time.time() - ts < 300:
                return active_id

        # 2. Mapeamento persistente no banco
        saved = await database.load_asset_mapping(symbol_upper, instrument)
        if saved:
            active_id = saved["active_id"]
            self._active_id_cache[cache_key] = (active_id, time.time())
            logger.debug(f"📦 {symbol_upper} [{instrument}] → ID {active_id} (banco)")
            return active_id

        # 3. Buscar na API
        try:
            result = await asyncio.wait_for(
                self.iq.get_actives(instrument),
                timeout=10.0
            )

            if not result or not isinstance(result, dict):
                return None

            # Variações para tentar em ordem:
            # EURAUD → ["EURAUD", "EUR/AUD", "EUR AUD"]
            variations = [
                symbol_upper,
                f"{symbol_upper[:3]}/{symbol_upper[3:]}",  # EUR/AUD
                f"{symbol_upper[:3]} {symbol_upper[3:]}",  # EUR AUD
            ]
            if is_otc:
                variations += [f"{v}-OTC" for v in variations]

            # Indexar todos os ativos para log de diagnóstico
            all_names = {}
            for active_id, data in result.items():
                if not isinstance(data, dict):
                    continue
                name   = str(data.get("name",   "")).upper().strip()
                ticker = str(data.get("ticker", "")).upper().strip()
                all_names[int(active_id)] = (name, ticker)

            # Tentar cada variação
            for variation in variations:
                var_clean = variation.replace("/", "").replace(" ", "").replace("-OTC", "")
                for active_id, (name, ticker) in all_names.items():
                    name_clean   = name.replace("/", "").replace(" ", "").replace("-OTC", "")
                    ticker_clean = ticker.replace("/", "").replace(" ", "").replace("-OTC", "")

                    if is_otc:
                        match = (var_clean in name_clean and "OTC" in name)
                    else:
                        match = (name_clean == var_clean or ticker_clean == var_clean)

                    if match:
                        logger.info(
                            f"✅ {symbol_upper} → ID {active_id} "
                            f"(IQ name: '{name}') [{instrument}]"
                        )
                        # Salvar no cache e no banco
                        self._active_id_cache[cache_key] = (active_id, time.time())
                        await database.save_asset_mapping(symbol_upper, instrument, active_id, name)
                        return active_id

            # Não encontrou — logar ativos próximos para diagnóstico
            partial = [
                f"ID:{aid} name='{n}' ticker='{t}'"
                for aid, (n, t) in list(all_names.items())[:5]
                if symbol_upper[:3] in n or symbol_upper[:3] in t
            ]
            if partial:
                logger.warning(
                    f"⚠️ {symbol_upper} não encontrado em [{instrument}]. "
                    f"Ativos similares: {' | '.join(partial)}"
                )
            else:
                logger.warning(f"⚠️ {symbol_upper} não encontrado em [{instrument}]")

            return None

        except asyncio.TimeoutError:
            logger.warning(f"⏱️ Timeout ao descobrir active_id para {symbol_upper} [{instrument}]")
            return None
        except Exception as e:
            logger.debug(f"Erro ao descobrir active_id: {e}")
            return None
    
    async def validate_asset_live(self, asset_symbol: str) -> Dict:
        """
        Valida ativo DINAMICAMENTE tentando ambos os instrumentos.
        Usa APENAS API pública (get_actives, get_profit_percent, is_active_open).
        
        Returns:
            {
                "valid": bool,
                "active_id": int,
                "instrument": "turbo" | "digital",
                "payout": int,
                "error": str (se invalid)
            }
        """
        try:
            if not await self.ensure_connection():
                return {"valid": False, "error": "Websocket desconectado"}
            
            debug = self.config.get("debug_trade_validation", False)
            
            # Tentar turbo primeiro
            if debug:
                logger.info(f"🔍 Procurando {asset_symbol} em turbo...")
            
            turbo_id = await self._discover_active_id(asset_symbol, "turbo")
            
            if turbo_id:
                turbo_result = await self._check_instrument_live(
                    turbo_id, "turbo", asset_symbol
                )
                if turbo_result["valid"]:
                    if debug:
                        logger.info(
                            f"✅ {asset_symbol} disponível [turbo] "
                            f"ID:{turbo_id} Payout:{turbo_result['payout']}%"
                        )
                    return turbo_result
            
            # Tentar digital como fallback
            if debug:
                logger.info(f"🔍 Procurando {asset_symbol} em digital...")
            
            digital_id = await self._discover_active_id(asset_symbol, "digital")
            
            if digital_id:
                digital_result = await self._check_instrument_live(
                    digital_id, "digital", asset_symbol
                )
                if digital_result["valid"]:
                    if debug:
                        logger.info(
                            f"✅ {asset_symbol} disponível [digital] "
                            f"ID:{digital_id} Payout:{digital_result['payout']}%"
                        )
                    return digital_result
            
            # Ambos falharam
            return {
                "valid": False,
                "error": f"Ativo {asset_symbol} fechado ou indisponível"
            }
            
        except Exception as e:
            logger.error(f"❌ Erro na validação live: {e}")
            return {"valid": False, "error": str(e)}
    
    async def _check_instrument_live(
        self,
        active_id: int,
        instrument: str,
        asset_name: str
    ) -> Dict:
        """
        Verifica se um instrumento específico está disponível.
        Usa apenas métodos públicos: get_profit_percent, is_active_open.
        """
        try:
            # 1) Obter payout (indica disponibilidade)
            try:
                payout = self.iq.get_profit_percent(active_id)
            except AttributeError:
                return {
                    "valid": False,
                    "active_id": active_id,
                    "instrument": instrument,
                    "payout": 0,
                    "error": "Método get_profit_percent não disponível"
                }
            except Exception as e:
                return {
                    "valid": False,
                    "active_id": active_id,
                    "instrument": instrument,
                    "payout": 0,
                    "error": f"Erro ao obter payout: {str(e)}"
                }
            
            # 2) Validar payout mínimo
            if payout < 50:
                return {
                    "valid": False,
                    "active_id": active_id,
                    "instrument": instrument,
                    "payout": payout,
                    "error": "Payout insuficiente ou ativo fechado"
                }
            
            min_payout = self.config.get("min_payout_percent", 70)
            if payout < min_payout:
                return {
                    "valid": False,
                    "active_id": active_id,
                    "instrument": instrument,
                    "payout": payout,
                    "error": f"Payout abaixo do mínimo ({payout}% < {min_payout}%)"
                }
            
            # 3) Verificar se está aberto (respeitando bypass_schedule_check)
            bypass = self.config.get("bypass_schedule_check", True)
            if not bypass and hasattr(self.iq, "is_active_open"):
                try:
                    is_open = self.iq.is_active_open(active_id)
                    if not is_open:
                        return {
                            "valid": False,
                            "active_id": active_id,
                            "instrument": instrument,
                            "payout": payout,
                            "error": "Ativo fechado (fora do horário)"
                        }
                except Exception:
                    pass  # Método pode falhar, continuar
            
            # Tudo OK
            return {
                "valid": True,
                "active_id": active_id,
                "instrument": instrument,
                "payout": payout
            }
            
        except Exception as e:
            return {
                "valid": False,
                "error": f"Erro crítico: {str(e)}"
            }
    
    async def execute_trade(
        self,
        asset_symbol: str,
        direction: str,
        amount: float,
        timeframe_minutes: int
    ) -> Tuple[bool, Optional[str], Optional[str]]:
        """
        Executa trade com validação live e seleção dinâmica de instrumento.
        
        Args:
            asset_symbol: Símbolo do ativo (ex: EURUSD, GBPUSD-OTC)
            direction: CALL ou PUT
            amount: Valor em dólares
            timeframe_minutes: 1, 5 ou 15
        
        Returns:
            (sucesso, order_id, mensagem_erro_pt_br)
        """
        try:
            # 1) Verificar se tem trade pendente
            if self._pending_trade:
                return False, None, "⏳ Trade anterior ainda em execução"
            
            # Cooldown is managed by ExecutionEngine/RiskManager
            
            # 3) Garantir conexão
            if not await self.ensure_connection():
                return False, None, "🔌 Websocket desconectado"

            # 4) Verificar saldo da conta ativa (PRACTICE ou REAL)
            balances = await self.iq.get_balances()
            active_id = self.iq.active_balance_id
            active_bal = next((b for b in balances if b.id == active_id), None)
            if not active_bal or active_bal.amount < amount:
                saldo_atual = active_bal.amount if active_bal else 0
                return False, None, f"💰 Saldo insuficiente (${saldo_atual:.2f})"
            
            # 6) Validar ativo LIVE
            validation = await self.validate_asset_live(asset_symbol)
            
            if not validation["valid"]:
                error_msg = validation.get("error", "Ativo indisponível")
                return False, None, f"❌ {error_msg}"
            
            active_id = validation["active_id"]
            instrument = validation["instrument"]
            payout = validation["payout"]
            
            logger.info(
                f"🎯 Executando: {asset_symbol} {direction} ${amount} "
                f"[{instrument}] ID:{active_id} Payout:{payout}%"
            )
            
            # 7) Marcar trade como iniciado
            self._pending_trade = True
            self._last_trade_time = datetime.now()
            
            # 8) Executar baseado no modo de operação (BLITZ, BINARY ou AUTO)
            duration_seconds = timeframe_minutes * 60
            direction_lower = direction.lower()

            # Verificar modo de operação configurado
            modo_operacao = self.config.get("modo_operacao", "BLITZ").upper()

            # --- Martingale instrument lock ---
            # During a Martingale sequence the instrument must not change.
            # We persist the instrument chosen at level-0 and reuse it.
            martingale_instrument = self.config.get("_martingale_instrument_lock")

            try:
                if modo_operacao == "BINARY":
                    chosen_instrument = "binary"
                elif modo_operacao == "BLITZ":
                    chosen_instrument = "blitz"
                else:
                    # AUTO mode: select instrument with higher payout
                    # to respect martingale lock, check if there's an active lock
                    if martingale_instrument:
                        chosen_instrument = martingale_instrument
                        logger.debug(f"AUTO: mantendo instrumento do Martingale → {chosen_instrument}")
                    else:
                        # Compare blitz vs binary payout for this asset
                        blitz_payout = self.iq.get_profit_percent(active_id)
                        # Binary payout from cache (binary category)
                        binary_payout = 0
                        try:
                            s_id = str(active_id)
                            binary_data = self.iq.actives_cache.get("binary-option", {}).get(s_id) or \
                                          self.iq.actives_cache.get("binary", {}).get(s_id) or {}
                            if binary_data:
                                try:
                                    commission = binary_data.get("option", {}).get("profit", {}).get("commission")
                                    if commission is not None:
                                        binary_payout = 100 - int(commission)
                                    elif "profit_percent" in binary_data:
                                        binary_payout = binary_data["profit_percent"]
                                except Exception:
                                    binary_payout = 0
                        except Exception:
                            binary_payout = 0

                        if blitz_payout >= binary_payout:
                            chosen_instrument = "blitz"
                        else:
                            chosen_instrument = "binary"
                        logger.info(
                            f"AUTO: blitz_payout={blitz_payout}% binary_payout={binary_payout}% "
                            f"→ usando {chosen_instrument}"
                        )

                if chosen_instrument == "binary":
                    result = await self._execute_binary(
                        active_id, direction_lower, amount, duration_seconds
                    )
                else:
                    result = await self._execute_turbo(
                        active_id, direction_lower, amount, duration_seconds
                    )
                
                # 9) Processar resultado
                if result["success"]:
                    order_id = result["order_id"]
                    logger.info(f"✅ Trade executado: ID {order_id}")
                    # Cache full result for ExecutionEngine settlement
                    if "raw_result" in result:
                        self._last_trade_result[str(order_id)] = result["raw_result"]
                    return True, order_id, None
                else:
                    error = result.get("error", "Erro desconhecido")
                    logger.error(f"❌ Falha no trade: {error}")
                    return False, None, f"❌ {error}"
                    
            except Exception as e:
                logger.error(f"❌ Erro na execução: {e}")
                import traceback
                logger.error(traceback.format_exc())
                return False, None, f"❌ Erro na execução: {str(e)}"
            finally:
                # Garante reset do flag independente de qualquer exceção
                self._pending_trade = False
                
        except Exception as e:
            self._pending_trade = False
            logger.error(f"❌ Erro crítico: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return False, None, f"❌ Erro crítico: {str(e)}"    
    async def _execute_turbo(
        self,
        active_id: int,
        direction: str,
        amount: float,
        duration: int
    ) -> Dict:
        """
        Executa trade em turbo/blitz usando buy_blitz() diretamente.
        """
        try:
            debug = self.config.get("debug_trade_validation", False)

            if debug:
                logger.info(
                    f"📤 Executando blitz: active_id={active_id}, "
                    f"direction={direction}, amount={amount}, duration={duration}"
                )

            if not hasattr(self.iq, "buy_blitz"):
                return {
                    "success": False,
                    "error": "Método buy_blitz não disponível no cliente IQ Option"
                }

            result = await self.iq.buy_blitz(
                active_id=active_id,
                direction=direction,
                amount=amount,
                duration=duration
            )

            if not result:
                return {"success": False, "error": "API não retornou resposta"}

            # buy_blitz retorna: {"status": "closed", "result": "win|loose|equal", "pnl": ..., "order_id": ...}
            # Verificar timeout/erro
            if result.get("result") == "timeout":
                return {"success": False, "error": "Timeout aguardando resultado da ordem"}

            # Extrair order_id do resultado de buy_blitz
            order_id = result.get("order_id") or result.get("id") or result.get("external_id")

            if not order_id:
                api_message = result.get("message", result.get("msg", "Sem detalhes"))
                if isinstance(api_message, dict):
                    api_message = api_message.get("message", str(api_message))
                return {
                    "success": False,
                    "error": f"Ordem rejeitada: {api_message}"
                }

            # Passar resultado completo como raw_result para settlement imediato
            raw_result = {
                "result": result.get("result", "unknown"),
                "pnl": result.get("pnl", result.get("profit", 0.0)),
                "order_id": str(order_id),
            }
            return {"success": True, "order_id": str(order_id), "raw_result": raw_result}

        except Exception as e:
            logger.error(f"❌ Erro em blitz/turbo: {e}")
            return {"success": False, "error": str(e)}
    
    async def _execute_binary(
        self,
        active_id: int,
        direction: str,
        amount: float,
        duration: int
    ) -> Dict:
        """
        Executa trade em modo BINÁRIO (binary-option).
        Usa buy_binary() que aguarda resultado com polling robusto.
        Settlement: nunca retorna unknown — fallback para loss no timeout.
        """
        try:
            debug = self.config.get("debug_trade_validation", False)

            if debug:
                logger.info(
                    f"📤 Executando binary: active_id={active_id}, "
                    f"direction={direction}, amount={amount}, duration={duration}"
                )

            # Verificar se método buy_binary() está disponível
            if not hasattr(self.iq, "buy_binary"):
                return {
                    "success": False,
                    "error": "Método buy_binary() não disponível no cliente IQ Option"
                }

            # Executar ordem binária — buy_binary lida com settlement internamente
            result = await self.iq.buy_binary(
                active_id=active_id,
                direction=direction,
                amount=amount,
                duration=duration
            )

            if not result:
                return {"success": False, "error": "API não retornou resposta"}

            order_id = result.get("order_id")

            # Se order_id está vazio, significa erro no ACK
            if not order_id:
                return {
                    "success": False,
                    "error": f"Ordem binária rejeitada ou sem ID"
                }

            logger.info(f"✅ Ordem binária resolvida: ID {order_id} → {result.get('result')}")

            # Normalise result string for settlement cache
            raw_result = {
                "result": result.get("result", "loss"),  # never unknown
                "pnl": result.get("pnl", -amount),
                "order_id": str(order_id),
            }
            return {"success": True, "order_id": str(order_id), "raw_result": raw_result}

        except Exception as e:
            logger.error(f"❌ Erro em binary: {e}")
            return {"success": False, "error": str(e)}
    
    async def _execute_digital(
        self,
        active_id: int,
        direction: str,
        amount: float,
        duration: int
    ) -> Dict:
        """
        Executa trade em digital.
        Usa método público buy_digital_spot() ou equivalente.
        """
        try:
            debug = self.config.get("debug_trade_validation", False)
            
            if debug:
                logger.info(
                    f"📤 Executando digital: active_id={active_id}, "
                    f"direction={direction}, amount={amount}, duration={duration}"
                )
            
            if not hasattr(self.iq, "buy_digital_spot"):
                return {
                    "success": False,
                    "error": "Método buy_digital_spot não disponível"
                }
            
            result = await self.iq.buy_digital_spot(
                active_id=active_id,
                direction=direction,
                amount=amount,
                duration=duration
            )
            
            if not result:
                return {"success": False, "error": "API não retornou resposta"}
            
            order_id = result.get("id") or result.get("order_id") or result.get("external_id")
            
            if not order_id:
                api_message = result.get("message", result.get("msg", "Sem detalhes"))
                if isinstance(api_message, dict):
                    api_message = api_message.get("message", str(api_message))
                return {
                    "success": False,
                    "error": f"Ordem rejeitada: {api_message}"
                }
            
            return {"success": True, "order_id": str(order_id)}
            
        except AttributeError:
            return {
                "success": False,
                "error": "Método buy_digital_spot não disponível"
            }
        except Exception as e:
            logger.error(f"❌ Erro em digital: {e}")
            return {"success": False, "error": str(e)}

