"""
Módulo de Indicadores Técnicos — Bot Q3 Beta
Calcula RSI, MACD, Bandas de Bollinger e EMA via Pandas de forma vetorizada.

ISOLAMENTO TOTAL:
- Não importa nenhum módulo interno do bot
- Não altera nenhum fluxo existente
- Retorna sempre um dict seguro (nunca lança exceção para cima)
- Compatível com candles no formato dict {open, high, low, close} OU objeto com atributos

USO:
    from core.technical_indicators import calcular_indicadores
    indicadores = calcular_indicadores(candles)
"""

import logging
from typing import List, Union, Dict, Any, Optional

logger = logging.getLogger(__name__)

# ── Importação defensiva do Pandas ────────────────────────────────────────────
try:
    import pandas as pd
    import numpy as np
    _PANDAS_OK = True
except ImportError:
    _PANDAS_OK = False
    logger.warning(
        "⚠️ [technical_indicators] pandas/numpy não encontrado. "
        "Instale com: pip install pandas numpy. "
        "Indicadores técnicos estarão desativados."
    )


# ─────────────────────────────────────────────────────────────────────────────
# CONSTANTES PADRÃO
# ─────────────────────────────────────────────────────────────────────────────

RSI_PERIOD: int = 14
EMA_FAST: int = 9
EMA_SLOW: int = 21
MACD_FAST: int = 12
MACD_SLOW: int = 26
MACD_SIGNAL: int = 9
BB_PERIOD: int = 20
BB_STD: float = 2.0

# Mínimo de candles necessários para cálculo confiável
MIN_CANDLES: int = 30


# ─────────────────────────────────────────────────────────────────────────────
# HELPERS INTERNOS
# ─────────────────────────────────────────────────────────────────────────────

def _extrair_close(candle: Any) -> Optional[float]:
    """Extrai o preço de fechamento de um candle (dict ou objeto)."""
    try:
        if isinstance(candle, dict):
            return float(candle.get("close", 0))
        return float(getattr(candle, "close", 0))
    except (TypeError, ValueError):
        return None


def _candles_para_series(candles: List[Any]) -> Optional["pd.Series"]:
    """
    Converte lista de candles para pd.Series de closes.
    Retorna None se dados insuficientes ou inválidos.
    """
    if not _PANDAS_OK:
        return None

    closes = []
    for c in candles:
        valor = _extrair_close(c)
        if valor is not None and valor > 0:
            closes.append(valor)

    if len(closes) < MIN_CANDLES:
        logger.debug(
            f"[technical_indicators] Candles insuficientes: "
            f"{len(closes)} (mínimo: {MIN_CANDLES})"
        )
        return None

    return pd.Series(closes, dtype=float)


# ─────────────────────────────────────────────────────────────────────────────
# CÁLCULOS INDIVIDUAIS (todos vetorizados, sem loops Python)
# ─────────────────────────────────────────────────────────────────────────────

def _calcular_rsi(series: "pd.Series", period: int = RSI_PERIOD) -> Optional[float]:
    """
    RSI via método Wilder (EWM com alpha = 1/period).
    Retorna o valor mais recente arredondado em 2 casas.
    """
    if len(series) < period + 1:
        return None

    delta = series.diff()
    ganho = delta.clip(lower=0)
    perda = (-delta).clip(lower=0)

    # EWM com adjust=False replica o smoothing de Wilder
    media_ganho = ganho.ewm(alpha=1 / period, adjust=False).mean()
    media_perda = perda.ewm(alpha=1 / period, adjust=False).mean()

    # Evita divisão por zero
    rs = media_ganho / media_perda.replace(0, float("nan"))
    rsi = 100 - (100 / (1 + rs))

    valor = rsi.iloc[-1]
    if pd.isna(valor):
        return None
    return round(float(valor), 2)


def _calcular_ema(series: "pd.Series", period: int) -> Optional[float]:
    """
    EMA padrão (exponentially weighted mean).
    Retorna o valor mais recente arredondado em 5 casas.
    """
    if len(series) < period:
        return None

    ema = series.ewm(span=period, adjust=False).mean()
    valor = ema.iloc[-1]
    if pd.isna(valor):
        return None
    return round(float(valor), 5)


def _calcular_macd(
    series: "pd.Series",
    fast: int = MACD_FAST,
    slow: int = MACD_SLOW,
    signal: int = MACD_SIGNAL,
) -> Optional[Dict[str, float]]:
    """
    MACD = EMA(fast) - EMA(slow)
    Sinal = EMA(MACD, signal)
    Histograma = MACD - Sinal
    Retorna dict com chaves: linha, sinal, histograma
    """
    if len(series) < slow + signal:
        return None

    ema_fast = series.ewm(span=fast, adjust=False).mean()
    ema_slow = series.ewm(span=slow, adjust=False).mean()
    macd_line = ema_fast - ema_slow
    signal_line = macd_line.ewm(span=signal, adjust=False).mean()
    histograma = macd_line - signal_line

    linha_val = macd_line.iloc[-1]
    sinal_val = signal_line.iloc[-1]
    hist_val = histograma.iloc[-1]

    if any(pd.isna(v) for v in [linha_val, sinal_val, hist_val]):
        return None

    return {
        "linha": round(float(linha_val), 6),
        "sinal": round(float(sinal_val), 6),
        "histograma": round(float(hist_val), 6),
    }


def _calcular_bollinger(
    series: "pd.Series",
    period: int = BB_PERIOD,
    num_std: float = BB_STD,
) -> Optional[Dict[str, float]]:
    """
    Bandas de Bollinger: média móvel simples ± (num_std × desvio padrão).
    Retorna dict com: media, superior, inferior, largura, posicao_relativa
    posicao_relativa: 0.0 = banda inferior, 1.0 = banda superior
    """
    if len(series) < period:
        return None

    sma = series.rolling(window=period).mean()
    std = series.rolling(window=period).std(ddof=0)

    banda_sup = sma + (num_std * std)
    banda_inf = sma - (num_std * std)

    media_val = sma.iloc[-1]
    sup_val = banda_sup.iloc[-1]
    inf_val = banda_inf.iloc[-1]
    preco_atual = series.iloc[-1]

    if any(pd.isna(v) for v in [media_val, sup_val, inf_val]):
        return None

    largura = sup_val - inf_val
    posicao = (
        (preco_atual - inf_val) / largura
        if largura > 0
        else 0.5
    )

    return {
        "media": round(float(media_val), 5),
        "superior": round(float(sup_val), 5),
        "inferior": round(float(inf_val), 5),
        "largura": round(float(largura), 6),
        "posicao_relativa": round(float(posicao), 3),
    }


# ─────────────────────────────────────────────────────────────────────────────
# INTERPRETADORES (geram texto para o prompt da IA)
# ─────────────────────────────────────────────────────────────────────────────

def _interpretar_rsi(rsi: float) -> str:
    if rsi >= 70:
        return f"{rsi:.1f} → sobrecomprado (possível reversão BAIXA)"
    elif rsi <= 30:
        return f"{rsi:.1f} → sobrevendido (possível reversão ALTA)"
    elif rsi >= 55:
        return f"{rsi:.1f} → momentum positivo (viés ALTA)"
    elif rsi <= 45:
        return f"{rsi:.1f} → momentum negativo (viés BAIXA)"
    else:
        return f"{rsi:.1f} → neutro"


def _interpretar_macd(macd: Dict[str, float]) -> str:
    hist = macd["histograma"]
    linha = macd["linha"]
    sinal = macd["sinal"]

    if linha > sinal and hist > 0:
        forca = "forte" if hist > abs(linha) * 0.3 else "fraco"
        return f"CALL ({forca}) | linha={linha:.6f} sinal={sinal:.6f} hist={hist:.6f}"
    elif linha < sinal and hist < 0:
        forca = "forte" if abs(hist) > abs(linha) * 0.3 else "fraco"
        return f"PUT ({forca}) | linha={linha:.6f} sinal={sinal:.6f} hist={hist:.6f}"
    else:
        return f"neutro | linha={linha:.6f} sinal={sinal:.6f} hist={hist:.6f}"


def _interpretar_bollinger(bb: Dict[str, float], preco_atual: float) -> str:
    pos = bb["posicao_relativa"]
    largura = bb["largura"]

    if pos >= 0.95:
        zona = "toco banda SUPERIOR (sobrecomprado)"
    elif pos <= 0.05:
        zona = "toco banda INFERIOR (sobrevendido)"
    elif pos >= 0.75:
        zona = "região superior da banda"
    elif pos <= 0.25:
        zona = "região inferior da banda"
    else:
        zona = "região central"

    squeeze = " [SQUEEZE — baixa volatilidade]" if largura < 0.0005 else ""

    return (
        f"pos={pos:.2f} ({zona}){squeeze} | "
        f"sup={bb['superior']:.5f} med={bb['media']:.5f} inf={bb['inferior']:.5f}"
    )


def _interpretar_ema_cruzamento(ema_fast: float, ema_slow: float) -> str:
    diff = ema_fast - ema_slow
    if diff > 0:
        return f"EMA{EMA_FAST} ACIMA EMA{EMA_SLOW} → tendência ALTA ({diff:+.5f})"
    elif diff < 0:
        return f"EMA{EMA_FAST} ABAIXO EMA{EMA_SLOW} → tendência BAIXA ({diff:+.5f})"
    else:
        return f"EMA{EMA_FAST} = EMA{EMA_SLOW} → cruzamento iminente"


# ─────────────────────────────────────────────────────────────────────────────
# INTERFACE PÚBLICA PRINCIPAL
# ─────────────────────────────────────────────────────────────────────────────

def calcular_indicadores(candles: List[Any]) -> Dict[str, Any]:
    """
    Calcula todos os indicadores técnicos para uma lista de candles.

    Args:
        candles: Lista de candles (dict com 'close' ou objeto com atributo .close)

    Returns:
        Dict com chaves:
            - rsi: float ou None
            - macd: dict {linha, sinal, histograma} ou None
            - bollinger: dict {media, superior, inferior, largura, posicao_relativa} ou None
            - ema_fast: float ou None  (EMA 9)
            - ema_slow: float ou None  (EMA 21)
            - disponivel: bool (False se pandas não instalado ou dados insuficientes)
            - erro: str ou None (mensagem de erro se houver)
    """
    resultado_vazio = {
        "rsi": None,
        "macd": None,
        "bollinger": None,
        "ema_fast": None,
        "ema_slow": None,
        "disponivel": False,
        "erro": None,
    }

    if not _PANDAS_OK:
        resultado_vazio["erro"] = "pandas não instalado"
        return resultado_vazio

    if not candles:
        resultado_vazio["erro"] = "lista de candles vazia"
        return resultado_vazio

    try:
        series = _candles_para_series(candles)
        if series is None:
            resultado_vazio["erro"] = f"candles insuficientes (mín. {MIN_CANDLES})"
            return resultado_vazio

        rsi = _calcular_rsi(series)
        macd = _calcular_macd(series)
        bb = _calcular_bollinger(series)
        ema_fast = _calcular_ema(series, EMA_FAST)
        ema_slow = _calcular_ema(series, EMA_SLOW)

        return {
            "rsi": rsi,
            "macd": macd,
            "bollinger": bb,
            "ema_fast": ema_fast,
            "ema_slow": ema_slow,
            "disponivel": any(v is not None for v in [rsi, macd, bb, ema_fast, ema_slow]),
            "erro": None,
        }

    except Exception as e:
        logger.error(f"[technical_indicators] Erro inesperado ao calcular indicadores: {e}")
        resultado_vazio["erro"] = str(e)
        return resultado_vazio


def formatar_para_prompt(candles: List[Any], ativo: str = "") -> str:
    """
    Interface de alto nível: calcula indicadores e retorna bloco de texto
    formatado pronto para inserção no prompt da IA.

    Args:
        candles: Lista de candles
        ativo: Nome do ativo (opcional, usado apenas no cabeçalho)

    Returns:
        String formatada com os indicadores, ou string vazia se indisponível.
        NUNCA lança exceção.
    """
    try:
        ind = calcular_indicadores(candles)

        if not ind["disponivel"]:
            motivo = ind.get("erro") or "dados insuficientes"
            logger.debug(
                f"[technical_indicators] Indicadores indisponíveis "
                f"para {ativo or 'ativo'}: {motivo}"
            )
            return ""

        # Preço atual para contexto do Bollinger
        preco_atual = _extrair_close(candles[-1]) if candles else 0.0

        linhas = []
        prefixo = f"[INDICADORES TÉCNICOS — {ativo}]" if ativo else "[INDICADORES TÉCNICOS]"
        linhas.append(prefixo)

        # RSI
        if ind["rsi"] is not None:
            linhas.append(f"  RSI({RSI_PERIOD}): {_interpretar_rsi(ind['rsi'])}")

        # MACD
        if ind["macd"] is not None:
            linhas.append(f"  MACD({MACD_FAST},{MACD_SLOW},{MACD_SIGNAL}): {_interpretar_macd(ind['macd'])}")

        # Bollinger
        if ind["bollinger"] is not None and preco_atual:
            linhas.append(
                f"  Bollinger({BB_PERIOD},{BB_STD}): "
                f"{_interpretar_bollinger(ind['bollinger'], preco_atual)}"
            )

        # EMA Cruzamento
        if ind["ema_fast"] is not None and ind["ema_slow"] is not None:
            linhas.append(
                f"  EMA: {_interpretar_ema_cruzamento(ind['ema_fast'], ind['ema_slow'])}"
            )

        return "\n".join(linhas)

    except Exception as e:
        logger.error(f"[technical_indicators] Erro em formatar_para_prompt: {e}")
        return ""
