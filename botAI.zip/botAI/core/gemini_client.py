"""
Gemini Client — Bot Q3 Beta
REST API com X-goog-api-key. Modelo: gemini-2.0-flash.
Rate limit: plano gratuito = 15 req/min. Retry automático com backoff.
"""
import logging
import time
import requests
from typing import Optional, List, Dict

logger = logging.getLogger(__name__)

MODEL = "gemini-2.0-flash"
BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"

# Rate limiter simples: máximo de chamadas por minuto
_last_calls = []          # timestamps das últimas chamadas
MAX_CALLS_PER_MIN = 12    # conservador: 12/min (limite real é 15)


def _rate_limit_wait():
    """Bloqueia se necessário para não ultrapassar o limite."""
    now = time.time()
    # Remove chamadas com mais de 60s
    global _last_calls
    _last_calls = [t for t in _last_calls if now - t < 60]

    if len(_last_calls) >= MAX_CALLS_PER_MIN:
        # Espera até a chamada mais antiga completar 60s
        oldest = _last_calls[0]
        wait = 60 - (now - oldest) + 1
        if wait > 0:
            logger.info(f"⏳ Gemini rate limit — aguardando {wait:.0f}s")
            time.sleep(wait)
        _last_calls = [t for t in _last_calls if time.time() - t < 60]

    _last_calls.append(time.time())


class GeminiClient:

    def __init__(self, api_key: str, project_id: str = None):
        if not api_key:
            raise ValueError("GEMINI_API_KEY é obrigatória")
        self.api_key = api_key.strip()
        self.model_name = MODEL
        logger.info(f"✅ GeminiClient pronto — {self.model_name}")

    def generate(self, prompt: str, temperature: float = 0.7,
                 max_output_tokens: int = 512, _retry: int = 0) -> str:
        """
        Gera texto. Em caso de 429, aguarda 10s e tenta novamente (max 3x).
        """
        _rate_limit_wait()

        url = f"{BASE_URL}/{self.model_name}:generateContent"
        headers = {
            "Content-Type": "application/json",
            "X-goog-api-key": self.api_key,
        }
        payload = {
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {
                "temperature": temperature,
                "maxOutputTokens": max_output_tokens,
            }
        }

        try:
            resp = requests.post(url, json=payload, headers=headers, timeout=30)

            if resp.status_code == 429 and _retry < 3:
                wait = 10  # Per audit: retry after 10 seconds, max 3 retries
                logger.warning(f"⚠️ Gemini 429 — aguardando {wait}s (tentativa {_retry+1}/3)")
                time.sleep(wait)
                return self.generate(prompt, temperature, max_output_tokens, _retry + 1)

            resp.raise_for_status()
            data = resp.json()
            return data["candidates"][0]["content"]["parts"][0]["text"]

        except requests.exceptions.HTTPError as e:
            status = e.response.status_code if e.response else "?"
            if status == 429:
                raise RuntimeError("Gemini rate limit esgotado após 3 retries — previsão cancelada")
            raise

    async def analisar_contexto(self, prompt: str, temperature: float = 0.7) -> str:
        """
        Versão assíncrona de generate() para uso com asyncio.
        Executa a chamada bloqueante em um executor de thread para não bloquear o event loop.
        """
        import asyncio
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, lambda: self.generate(prompt, temperature))

    class ChatCompletions:
        def __init__(self, client):
            self.client = client

        def create(self, model: str, messages: List[Dict],
                   temperature: float = 0.7, max_tokens: Optional[int] = None):
            prompt = next(
                (m.get("content", "") for m in messages if m.get("role") == "user"), ""
            )
            text = self.client.generate(
                prompt, temperature=temperature,
                max_output_tokens=max_tokens or 512
            )

            class Choice:
                def __init__(self, t):
                    self.message = type("M", (), {"content": t})()

            class Response:
                def __init__(self, t):
                    self.choices = [Choice(t)]

            return Response(text)

    @property
    def chat(self):
        client = self
        class Chat:
            def __init__(self):
                self.completions = GeminiClient.ChatCompletions(client)
        return Chat()
