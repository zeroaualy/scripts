"""
Gerador de Agenda Diária de Sinais IA — Bot Q3 Beta
Gera uma lista completa de sinais para o dia usando Gemini AI + dados de mercado MyIQ.

Funcionalidades de segurança preservadas:
- asyncio.Lock(): apenas uma requisição IA por vez
- last_ai_call_timestamp: intervalo mínimo entre chamadas
- Retry: 3 tentativas, 10s entre tentativas, timeout de 45s por chamada
- Verificação de conexão antes de executar
- Nunca derruba o bot

Arquitetura:
- Gera UMA lista completa por dia (não sinais individuais por minuto)
- Envia UMA mensagem Telegram com a agenda completa
- Formato compatível com o parser existente: M5 ATIVO DIRECAO HH:MM
- AutoTrade executa os sinais automaticamente no horário correto
"""
import asyncio
import json
import logging
import re
import time
from datetime import datetime, timedelta
from typing import List, Optional, Dict
from zoneinfo import ZoneInfo

from state import runtime

logger = logging.getLogger(__name__)
TZ = ZoneInfo("America/Sao_Paulo")

# ── Indicadores técnicos (módulo isolado — não altera nenhum fluxo existente)
try:
    from core.market_context_builder import context_builder as _ctx_builder
    _INDICADORES_OK = True
except ImportError:
    _INDICADORES_OK = False
    logger.warning("⚠️ [future_signal_generator] market_context_builder não encontrado — indicadores desativados")

# ─────────────────────────────────────────────────────────
# POOL DE ATIVOS E HORÁRIOS DE CADA SESSÃO
# ─────────────────────────────────────────────────────────

_ATIVOS_DIA = [
    "EURUSD", "GBPUSD", "USDJPY", "AUDUSD",
    "EURJPY", "GBPJPY", "EURGBP", "AUDJPY", "USDCAD",
]
_ATIVOS_OTC = [
    "EURUSD-OTC", "GBPUSD-OTC", "USDJPY-OTC", "AUDUSD-OTC",
    "EURJPY-OTC", "GBPJPY-OTC", "EURGBP-OTC", "AUDJPY-OTC", "USDCAD-OTC",
]

# Horários fixos com espaçamento de 25 min (dentro do intervalo 20-30 min exigido)
_HORARIOS_MANHA = ["10:45", "11:10", "11:35"]
_HORARIOS_TARDE = [
    "12:00", "12:25", "12:50", "13:15", "13:40",
    "14:05", "14:30", "14:55", "15:20", "15:45",
    "16:10", "16:35",
]
_HORARIOS_NOITE = [
    "17:00", "17:25", "17:50", "18:15", "18:40",
    "19:05", "19:30", "19:55", "20:20", "20:45",
    "21:10", "21:35", "22:00", "22:25", "22:50", "23:15",
]

# Horário do ciclo diário (São Paulo)
_HORA_GERACAO = 9
_MINUTO_GERACAO = 0

# Intervalo mínimo entre chamadas Gemini (segundos)
MIN_CALL_INTERVAL = 30.0

_PROB_MINIMA_PADRAO = 0.60


def _gerar_slots(horarios: List[str], ativos_pool: List[str]) -> List[Dict]:
    """Distribui ativos em rotação pelo pool para cada horário."""
    n = len(ativos_pool)
    return [{"time": t, "asset": ativos_pool[i % n]} for i, t in enumerate(horarios)]


# Pré-computação dos slots do dia (imutáveis)
_SLOTS_MANHA = _gerar_slots(_HORARIOS_MANHA, _ATIVOS_DIA)
_SLOTS_TARDE = _gerar_slots(_HORARIOS_TARDE, _ATIVOS_DIA)
_SLOTS_NOITE = _gerar_slots(_HORARIOS_NOITE, _ATIVOS_OTC)
_TODOS_SLOTS = _SLOTS_MANHA + _SLOTS_TARDE + _SLOTS_NOITE

_MANHA_SET = set(_HORARIOS_MANHA)
_TARDE_SET = set(_HORARIOS_TARDE)


class FutureSignalGenerator:
    """
    Gerador de agenda diária de sinais via IA.

    Ciclo: gera ao iniciar → aguarda 09:00 SP → repete.
    Envia uma única mensagem Telegram com a agenda completa.
    Compatível com parser e AutoTrade existentes sem modificações.
    """

    def __init__(self, iq_client, gemini_client, notify_callback, config: dict):
        self.iq = iq_client
        self.gemini = gemini_client
        self.notify = notify_callback
        self.config = config

        self.prob_minima = float(config.get("ai_probabilidade_minima", _PROB_MINIMA_PADRAO))
        self._last_ai_call_timestamp: float = 0.0
        self.ai_lock = asyncio.Lock()
        self.active = False
        self._task: Optional[asyncio.Task] = None

    # ──────────────────────────────────────────────
    # CICLO DE VIDA
    # ──────────────────────────────────────────────

    async def start(self) -> bool:
        if self.active:
            logger.warning("⚠️ FutureSignalGenerator já está ativo")
            return False
        if not self.gemini:
            logger.error("❌ GeminiClient não disponível para o gerador de agenda")
            return False
        self.active = True
        self._task = asyncio.create_task(self._loop())
        logger.info("✅ 🔮 FutureSignalGenerator INICIADO — modo agenda diária")
        return True

    async def stop(self):
        self.active = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        logger.info("⏸️ 🔮 FutureSignalGenerator PAUSADO")

    # ──────────────────────────────────────────────
    # LOOP PRINCIPAL
    # ──────────────────────────────────────────────

    async def _loop(self):
        """Gera agenda imediatamente ao iniciar, depois a cada dia às 09:00 SP."""
        while self.active:
            try:
                if not self.iq.esta_conectado():
                    logger.warning("⚠️ IQ Option desconectada — aguardando 30s...")
                    await asyncio.sleep(30)
                    continue

                elapsed = time.monotonic() - self._last_ai_call_timestamp
                if elapsed < MIN_CALL_INTERVAL:
                    await asyncio.sleep(MIN_CALL_INTERVAL - elapsed)
                    continue

                logger.info("📊 🔮 Iniciando geração da agenda diária de sinais IA...")
                await self._gerar_e_enviar_agenda()
                await self._aguardar_proximo_ciclo()

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"❌ Erro no loop da agenda diária: {e}")
                await asyncio.sleep(60)

    # ──────────────────────────────────────────────
    # PIPELINE DE GERAÇÃO
    # ──────────────────────────────────────────────

    async def _gerar_e_enviar_agenda(self):
        """Pipeline: mercado → prompt → Gemini → parse → filtrar → formatar → enviar."""
        async with self.ai_lock:
            elapsed = time.monotonic() - self._last_ai_call_timestamp
            if elapsed < MIN_CALL_INTERVAL:
                return

            try:
                contexto = await self._coletar_contexto_mercado()
                prompt = self._construir_prompt_diario(contexto)

                logger.info("🧠 Consultando Gemini para agenda diária...")
                resposta_raw = await self._chamar_gemini_com_retry(prompt)
                self._last_ai_call_timestamp = time.monotonic()

                if resposta_raw is None:
                    logger.warning("⚠️ Gemini não retornou resposta — agenda não gerada")
                    return

                sinais = self._parsear_resposta_diaria(resposta_raw)
                if not sinais:
                    logger.warning("⚠️ Nenhum sinal válido na resposta da IA")
                    return

                aprovados = [
                    s for s in sinais
                    if float(s.get("probability", 0)) >= self.prob_minima
                ]
                if not aprovados:
                    logger.warning(
                        f"⚠️ Nenhum sinal com prob ≥ {self.prob_minima:.0%} — "
                        "agenda não enviada"
                    )
                    return

                logger.info(
                    f"✅ {len(aprovados)} sinais aprovados "
                    f"(prob ≥ {self.prob_minima:.0%}) de {len(sinais)} analisados"
                )

                mensagem = self._formatar_agenda(aprovados)
                if not mensagem:
                    logger.warning("⚠️ Agenda formatada vazia — nenhuma mensagem enviada")
                    return

                # ── Agendar os sinais no runtime para execução automática ──
                agendados = 0
                from core.signal_parser import parsear_sinal
                for s in aprovados:
                    linha = f"M5 {s['asset']} {s['direction']} {s['time']}"
                    sinais_parsed = parsear_sinal(linha)
                    for sinal in sinais_parsed:
                        sinal["signal_source"] = "ai_agenda"
                        sinal["signal_received_at"] = datetime.now(TZ)
                        runtime.adicionar_sinal(sinal)
                        agendados += 1

                logger.info(f"📅 {agendados} sinais agendados no runtime para execução automática")

                if self.notify:
                    await self.notify(mensagem)
                    logger.info("📤 ✅ Agenda diária de sinais IA enviada ao Telegram")

            except Exception as e:
                self._last_ai_call_timestamp = time.monotonic()
                logger.error(f"❌ Erro ao gerar agenda diária: {e}")

    # ──────────────────────────────────────────────
    # COLETA DE CONTEXTO DE MERCADO
    # ──────────────────────────────────────────────

    async def _coletar_contexto_mercado(self) -> Dict:
        """Coleta candles M1 de EURUSD, GBPUSD e USDJPY como contexto de mercado."""
        ativos = ["EURUSD", "GBPUSD", "USDJPY"]
        dados = {}
        for ativo in ativos:
            try:
                candles = await self._buscar_candles(ativo)
                if candles and len(candles) >= 5:
                    dados[ativo] = candles
            except Exception as e:
                logger.debug(f"⚠️ Candles indisponíveis para {ativo}: {e}")
        return dados

    async def _buscar_candles(self, ativo: str) -> List[Dict]:
        """Busca candles M1 resolvendo active_id via integration layer."""
        try:
            active_id = None
            if hasattr(self.iq, "_integration") and self.iq._integration:
                symbol_clean = ativo.replace("-OTC", "")
                for instrument in ("turbo", "binary", "digital"):
                    active_id = await self.iq._integration._discover_active_id(
                        symbol_clean, instrument
                    )
                    if active_id:
                        break

            if not active_id:
                return []

            raw = await self.iq.iq.get_candles(int(active_id), 60, 20)
            return [
                {
                    "open": float(c.open),
                    "high": float(c.max),
                    "low": float(c.min),
                    "close": float(c.close),
                    "time": c.at,
                }
                for c in raw
            ]
        except Exception as e:
            logger.debug(f"⚠️ Erro ao buscar candles de {ativo}: {e}")
            return []

    # ──────────────────────────────────────────────
    # CONSTRUÇÃO DO PROMPT
    # ──────────────────────────────────────────────

    def _construir_prompt_diario(self, contexto: Dict) -> str:
        """Constrói o prompt completo para a agenda diária — enriquecido com indicadores técnicos."""
        agora = datetime.now(TZ)

        # Resumo dos dados de mercado (mantido exatamente como estava)
        linhas_mkt = []
        for ativo, candles in contexto.items():
            if candles:
                ult = candles[-1]
                ant = candles[-5] if len(candles) >= 5 else candles[0]
                var = ((ult["close"] - ant["close"]) / ant["close"]) * 100
                tendencia = "ALTA" if var > 0 else "BAIXA"
                linhas_mkt.append(
                    f"  {ativo}: close={ult['close']:.5f}  variação={var:+.3f}%  tendência={tendencia}"
                )
        resumo_mkt = "\n".join(linhas_mkt) if linhas_mkt else "  (dados não disponíveis)"

        # ── Bloco de indicadores técnicos por ativo (isolado — falha silenciosa) ──
        bloco_indicadores = ""
        if _INDICADORES_OK and contexto:
            try:
                bloco_indicadores = _ctx_builder.construir_contexto_multi(contexto)
            except Exception:
                bloco_indicadores = ""

        secao_indicadores = (
            f"\nINDICADORES TÉCNICOS (calculados localmente via Pandas):\n{bloco_indicadores}\n"
            if bloco_indicadores
            else ""
        )

        # Lista de slots numerados para preenchimento pelo Gemini (mantido exatamente como estava)
        linhas_slots = "\n".join(
            f'  {{"idx": {i}, "time": "{s["time"]}", "asset": "{s["asset"]}"}}'
            for i, s in enumerate(_TODOS_SLOTS)
        )

        return f"""Você é um analista de opções binárias. Analise os dados e gere uma agenda de sinais para o dia.

HORÁRIO ATUAL (São Paulo): {agora.strftime('%d/%m/%Y %H:%M:%S')}

DADOS DE MERCADO (M1 – 20 últimas velas):
{resumo_mkt}
{secao_indicadores}
INSTRUÇÕES:
- Analise cada slot e decida a direção (CALL ou PUT)
- probability deve ser decimal 0.00 a 1.00
- Inclua APENAS slots com probability >= {self.prob_minima:.2f}
- Omita slots com probability abaixo de {self.prob_minima:.2f}
- Ativos com -OTC operam em mercado OTC (noite)
- Retorne SOMENTE JSON válido, sem texto extra, sem markdown

SLOTS DISPONÍVEIS:
[
{linhas_slots}
]

FORMATO DE RESPOSTA (array com apenas os slots aprovados):
[
  {{"idx": 0, "direction": "PUT", "probability": 0.72}},
  {{"idx": 3, "direction": "CALL", "probability": 0.68}}
]

Se nenhum slot tiver probability >= {self.prob_minima:.2f}, retorne: []
"""

    # ──────────────────────────────────────────────
    # CHAMADA GEMINI COM RETRY
    # ──────────────────────────────────────────────

    async def _chamar_gemini_com_retry(self, prompt: str) -> Optional[str]:
        """3 tentativas · 45s timeout cada · 10s entre tentativas."""
        for tentativa in range(1, 4):
            try:
                return await asyncio.wait_for(
                    self.gemini.analisar_contexto(prompt, temperature=0.3),
                    timeout=45.0,
                )
            except asyncio.TimeoutError:
                logger.warning(f"⏱️ Gemini timeout (tentativa {tentativa}/3)")
                if tentativa < 3:
                    await asyncio.sleep(10.0)
            except RuntimeError as e:
                logger.warning(f"⚠️ Gemini rate limit: {e}")
                return None
            except Exception as e:
                logger.warning(f"⚠️ Gemini erro tentativa {tentativa}/3: {e}")
                if tentativa < 3:
                    await asyncio.sleep(10.0)

        logger.error("❌ Gemini: todas as tentativas falharam — agenda cancelada")
        return None

    # ──────────────────────────────────────────────
    # PARSER DA RESPOSTA
    # ──────────────────────────────────────────────

    def _parsear_resposta_diaria(self, raw: str) -> List[Dict]:
        """
        Parseia array JSON da resposta Gemini.
        Resolve cada item ao slot correspondente via idx.
        Retorna lista de sinais válidos ou lista vazia em qualquer erro.
        """
        if not raw or not isinstance(raw, str):
            return []
        try:
            text = raw.strip()
            text = re.sub(r"^```(?:json)?\s*", "", text)
            text = re.sub(r"\s*```$", "", text)
            text = text.strip()

            data = json.loads(text)
            if not isinstance(data, list):
                logger.warning(f"⚠️ Resposta Gemini não é array: {text[:100]}")
                return []

            resultado = []
            for item in data:
                if not isinstance(item, dict):
                    continue

                direction = str(item.get("direction", "")).upper().strip()
                if direction not in ("CALL", "PUT"):
                    continue

                try:
                    prob = float(item.get("probability", 0))
                except (TypeError, ValueError):
                    continue
                if not (0.0 <= prob <= 1.0):
                    continue

                idx = item.get("idx")
                slot = None
                if idx is not None:
                    try:
                        slot = _TODOS_SLOTS[int(idx)]
                    except (IndexError, TypeError, ValueError):
                        pass

                if slot is None:
                    continue

                resultado.append({
                    "time": slot["time"],
                    "asset": slot["asset"],
                    "direction": direction,
                    "probability": prob,
                })

            return resultado

        except json.JSONDecodeError as e:
            logger.warning(f"⚠️ JSON inválido na resposta Gemini: {e} | raw: {raw[:200]}")
            return []
        except Exception as e:
            logger.error(f"❌ Erro ao parsear resposta diária: {e}")
            return []

    # ──────────────────────────────────────────────
    # FORMATAÇÃO DA AGENDA
    # ──────────────────────────────────────────────

    def _formatar_agenda(self, sinais: List[Dict]) -> str:
        """
        Formata os sinais aprovados no layout exato de agenda diária.

        Saída (exemplo):
            🌅 MANHÃ – Mercado Aberto


            M5 EURUSD PUT 10:45
            M5 USDJPY CALL 11:10

            ━━━━━━━━━━━━━━━━━━
            ☀️ TARDE – Continuidade Operacional

            M5 EURUSD CALL 12:00
            ...

            ━━━━━━━━━━━━━━━━━━
            🌙 NOITE – OTC

            M5 EURUSD-OTC CALL 17:00
            ...

        Cada linha de sinal é exatamente: M5 ATIVO DIRECAO HH:MM
        (formato compatível com o parser existente sem modificações)
        """
        manha = []
        tarde = []
        noite = []

        for s in sinais:
            linha = f"M5 {s['asset']} {s['direction']} {s['time']}"
            t = s["time"]
            if t in _MANHA_SET:
                manha.append((t, linha))
            elif t in _TARDE_SET:
                tarde.append((t, linha))
            else:
                noite.append((t, linha))

        manha.sort(key=lambda x: x[0])
        tarde.sort(key=lambda x: x[0])
        noite.sort(key=lambda x: x[0])

        if not manha and not tarde and not noite:
            return ""

        partes = []

        if manha:
            linhas = "\n".join(l for _, l in manha)
            partes.append(f"🌅 MANHÃ – Mercado Aberto\n\n\n{linhas}")

        if tarde:
            linhas = "\n".join(l for _, l in tarde)
            separador = "\n━━━━━━━━━━━━━━━━━━\n" if partes else ""
            partes.append(f"{separador}☀️ TARDE – Continuidade Operacional\n\n{linhas}")

        if noite:
            linhas = "\n".join(l for _, l in noite)
            separador = "\n━━━━━━━━━━━━━━━━━━\n" if partes else ""
            partes.append(f"{separador}🌙 NOITE – OTC\n\n{linhas}")

        return "".join(partes)

    # ──────────────────────────────────────────────
    # TEMPORIZAÇÃO DO CICLO DIÁRIO
    # ──────────────────────────────────────────────

    async def _aguardar_proximo_ciclo(self):
        """Aguarda até 09:00 São Paulo do próximo dia, respondendo rapidamente ao stop()."""
        if not self.active:
            return

        agora = datetime.now(TZ)
        proximo = agora.replace(
            hour=_HORA_GERACAO, minute=_MINUTO_GERACAO, second=0, microsecond=0
        )
        if proximo <= agora:
            proximo += timedelta(days=1)

        total_s = (proximo - agora).total_seconds()
        logger.info(
            f"⏰ 🔮 Próxima agenda em "
            f"{int(total_s // 3600)}h {int((total_s % 3600) // 60)}min "
            f"({proximo.strftime('%d/%m %H:%M')} SP)"
        )

        # Dorme em fatias de 60s para responder ao stop() sem demora excessiva
        while self.active:
            restante = (proximo - datetime.now(TZ)).total_seconds()
            if restante <= 0:
                break
            await asyncio.sleep(min(60.0, restante))
